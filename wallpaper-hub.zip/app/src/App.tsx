import { useState, useEffect } from 'react';
import './App.css';
import { Navbar } from './sections/Navbar';
import { Hero } from './sections/Hero';
import { Methods } from './sections/Methods';
import { Stats } from './sections/Stats';
import { Tips } from './sections/Tips';
import { IncomeCalculator } from './sections/IncomeCalculator';
import { MethodFinder } from './sections/MethodFinder';
import { Tools } from './sections/Tools';
import { PlatformReviews } from './sections/PlatformReviews';
import { Comparisons } from './sections/Comparisons';
import { Blog } from './sections/Blog';
import { Premium } from './sections/Premium';
import { FAQ } from './sections/FAQ';
import { Footer } from './sections/Footer';
import { Toaster } from '@/components/ui/sonner';

function App() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main>
        <Hero />
        <Stats />
        <Methods />
        <IncomeCalculator />
        <MethodFinder />
        <Tools />
        <PlatformReviews />
        <Comparisons />
        <Tips />
        <Blog />
        <Premium />
        <FAQ />
      </main>
      <Footer />
      
      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 w-12 h-12 bg-primary text-primary-foreground rounded-full shadow-lg hover:bg-primary/90 transition-all z-50 flex items-center justify-center glow-green"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
          </svg>
        </button>
      )}
      
      <Toaster position="top-center" />
    </div>
  );
}

export default App;
