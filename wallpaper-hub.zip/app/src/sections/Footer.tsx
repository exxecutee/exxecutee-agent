import { useState } from 'react';
import { 
  DollarSign, Mail, MapPin, Phone, Send, 
  Facebook, Twitter, Instagram, Youtube, Linkedin,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const footerLinks = {
  metodos: [
    { label: 'Freelancing', href: '#methods' },
    { label: 'Trading', href: '#methods' },
    { label: 'YouTube', href: '#methods' },
    { label: 'Dropshipping', href: '#methods' },
    { label: 'Affiliate Marketing', href: '#methods' },
    { label: 'Desarrollo Web', href: '#methods' },
  ],
  recursos: [
    { label: 'Calculadora', href: '#calculator' },
    { label: 'Test de Perfil', href: '#finder' },
    { label: 'Herramientas', href: '#tools' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Comparador', href: '#comparisons' },
    { label: 'Blog', href: '#blog' },
  ],
  empresa: [
    { label: 'Sobre Nosotros', href: '#' },
    { label: 'Contacto', href: '#' },
    { label: 'Carreras', href: '#' },
    { label: 'Prensa', href: '#' },
    { label: 'Partners', href: '#' },
  ],
  legal: [
    { label: 'Términos de Uso', href: '#' },
    { label: 'Privacidad', href: '#' },
    { label: 'Cookies', href: '#' },
    { label: 'Disclaimer', href: '#' },
    { label: 'Afiliados', href: '#' },
  ],
};

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'YouTube' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
];

export function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      toast.success('¡Gracias por suscribirte! Revisa tu email para confirmar.');
      setEmail('');
    }
  };

  return (
    <footer className="relative pt-24 pb-8">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background to-transparent" />
      
      {/* CTA Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-primary/20 via-primary/10 to-accent/10 rounded-3xl border border-primary/20 p-8 lg:p-12 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl lg:text-3xl font-bold mb-4">
                ¿Listo para empezar a{' '}
                <span className="text-gradient">ganar dinero?</span>
              </h2>
              <p className="text-muted-foreground mb-6">
                Únete a más de 2.5 millones de personas que ya están generando ingresos online. 
                Recibe las mejores oportunidades directamente en tu inbox.
              </p>
              <div className="flex flex-wrap gap-3">
                {['Sin spam', 'Cancela cuando quieras', 'Gratis'].map((item) => (
                  <span key={item} className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Check className="w-4 h-4 text-primary" />
                    {item}
                  </span>
                ))}
              </div>
            </div>
            <div>
              {!subscribed ? (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
                  <Input
                    type="email"
                    placeholder="Tu correo electrónico"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 bg-background/50 border-border/50"
                    required
                  />
                  <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90 whitespace-nowrap">
                    <Send className="w-4 h-4 mr-2" />
                    Suscribirme
                  </Button>
                </form>
              ) : (
                <div className="bg-green-500/10 rounded-xl p-6 text-center border border-green-500/30">
                  <Check className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <p className="text-green-400 font-medium">¡Gracias por suscribirte!</p>
                  <p className="text-sm text-muted-foreground">Revisa tu email para confirmar.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <a href="#hero" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-primary" />
              </div>
              <span className="font-bold text-lg">
                Gana<span className="text-primary">Dinero</span>
              </span>
            </a>
            <p className="text-sm text-muted-foreground mb-4">
              Tu guía completa para generar ingresos online. Métodos probados, consejos expertos y una comunidad de apoyo.
            </p>
            <div className="space-y-2 mb-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="w-4 h-4" />
                <span>hola@ganadinero.com</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>Global - Remoto</span>
              </div>
            </div>
            {/* Social Links */}
            <div className="flex gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center hover:bg-primary/20 transition-colors group"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Métodos</h4>
            <ul className="space-y-2">
              {footerLinks.metodos.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Recursos</h4>
            <ul className="space-y-2">
              {footerLinks.recursos.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Empresa</h4>
            <ul className="space-y-2">
              {footerLinks.empresa.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Legal</h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-border/50">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © {new Date().getFullYear()} GanaDinero. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-6">
              <span className="text-xs text-muted-foreground">
                Resultados individuales pueden variar.
              </span>
              <div className="flex items-center gap-4">
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-400"></span>
                  Todos los sistemas operativos
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
