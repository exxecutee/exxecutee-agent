import { useState } from 'react';
import { 
  Wrench, ExternalLink, Star, Check, Zap, Shield, 
  TrendingUp, DollarSign, Palette, Code, Video, FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Tool {
  id: number;
  name: string;
  description: string;
  category: string;
  icon: React.ElementType;
  rating: number;
  reviews: number;
  price: string;
  features: string[];
  affiliateLink: string;
  popular?: boolean;
}

const tools: Tool[] = [
  {
    id: 1,
    name: 'Canva Pro',
    description: 'Diseño gráfico fácil para redes sociales, presentaciones y más.',
    category: 'Diseño',
    icon: Palette,
    rating: 4.8,
    reviews: 50000,
    price: '$12.99/mes',
    features: ['Plantillas ilimitadas', 'Brand Kit', 'Fondo removidor', 'Programación de posts'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 2,
    name: 'Notion',
    description: 'Todo en uno: notas, bases de datos, wikis y gestión de proyectos.',
    category: 'Productividad',
    icon: FileText,
    rating: 4.9,
    reviews: 35000,
    price: 'Gratis / $8/mes',
    features: ['Workspaces ilimitados', 'Base de datos', 'Plantillas', 'Colaboración'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 3,
    name: 'TubeBuddy',
    description: 'Herramienta esencial para crecer en YouTube con SEO y análisis.',
    category: 'YouTube',
    icon: Video,
    rating: 4.7,
    reviews: 28000,
    price: '$4.50/mes',
    features: ['SEO de videos', 'Análisis de competencia', 'A/B testing', 'Bulk processing'],
    affiliateLink: '#'
  },
  {
    id: 4,
    name: 'Bluehost',
    description: 'Hosting confiable para tu blog o sitio web con WordPress.',
    category: 'Hosting',
    icon: Shield,
    rating: 4.5,
    reviews: 42000,
    price: '$2.95/mes',
    features: ['Dominio gratis', 'SSL gratis', 'WordPress 1-click', 'Soporte 24/7'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 5,
    name: 'Shopify',
    description: 'La plataforma #1 para crear tu tienda online y vender.',
    category: 'E-commerce',
    icon: DollarSign,
    rating: 4.8,
    reviews: 55000,
    price: '$29/mes',
    features: ['Tienda completa', 'Pagos integrados', 'Dropshipping', 'Apps ilimitadas'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 6,
    name: 'Ahrefs',
    description: 'Herramienta SEO profesional para analizar y mejorar tu tráfico.',
    category: 'SEO',
    icon: TrendingUp,
    rating: 4.9,
    reviews: 18000,
    price: '$99/mes',
    features: ['Análisis de keywords', 'Backlinks', 'Auditoría de site', 'Competencia'],
    affiliateLink: '#'
  },
  {
    id: 7,
    name: 'VS Code',
    description: 'Editor de código gratuito y potente para desarrollo web.',
    category: 'Desarrollo',
    icon: Code,
    rating: 4.9,
    reviews: 75000,
    price: 'Gratis',
    features: ['Extensiones', 'Debugging', 'Git integrado', 'Multi-lenguaje'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 8,
    name: 'Figma',
    description: 'Diseño colaborativo en la nube para interfaces y prototipos.',
    category: 'Diseño',
    icon: Palette,
    rating: 4.8,
    reviews: 32000,
    price: 'Gratis / $12/mes',
    features: ['Diseño colaborativo', 'Prototipos', 'Componentes', 'Plugins'],
    affiliateLink: '#'
  },
  {
    id: 9,
    name: 'ConvertKit',
    description: 'Email marketing para creadores. Construye tu lista de suscriptores.',
    category: 'Marketing',
    icon: Zap,
    rating: 4.7,
    reviews: 15000,
    price: 'Gratis / $9/mes',
    features: ['Automaciones', 'Landing pages', 'Formularios', 'Secuencias'],
    affiliateLink: '#'
  },
  {
    id: 10,
    name: 'Upwork',
    description: 'La plataforma más grande para encontrar trabajo freelance.',
    category: 'Freelance',
    icon: DollarSign,
    rating: 4.5,
    reviews: 68000,
    price: 'Gratis (10% fee)',
    features: ['Miles de clientes', 'Protección de pago', 'Perfil profesional', 'Reviews'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 11,
    name: 'Binance',
    description: 'El exchange de criptomonedas más grande del mundo.',
    category: 'Trading',
    icon: TrendingUp,
    rating: 4.6,
    reviews: 89000,
    price: 'Gratis (0.1% fee)',
    features: ['500+ criptos', 'Trading avanzado', 'Staking', 'Tarjeta de débito'],
    affiliateLink: '#',
    popular: true
  },
  {
    id: 12,
    name: 'Grammarly',
    description: 'Mejora tu escritura con correcciones y sugerencias inteligentes.',
    category: 'Escritura',
    icon: FileText,
    rating: 4.7,
    reviews: 45000,
    price: 'Gratis / $12/mes',
    features: ['Corrección avanzada', 'Tone detector', 'Plagiarism check', 'Integraciones'],
    affiliateLink: '#'
  }
];

const categories = ['Todos', 'Diseño', 'Productividad', 'YouTube', 'Hosting', 'E-commerce', 'SEO', 'Desarrollo', 'Marketing', 'Freelance', 'Trading', 'Escritura'];

export function Tools() {
  const [activeCategory, setActiveCategory] = useState('Todos');

  const filteredTools = activeCategory === 'Todos' 
    ? tools 
    : tools.filter(t => t.category === activeCategory);

  return (
    <section id="tools" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Wrench className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Herramientas Recomendadas</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Las herramientas que{' '}
            <span className="text-gradient">los pros usan</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubre las herramientas esenciales que te ayudarán a trabajar más rápido y generar más ingresos.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTools.map((tool) => (
            <div
              key={tool.id}
              className="group bg-card rounded-2xl border border-border/50 overflow-hidden hover-lift hover:border-primary/50 transition-all"
            >
              <div className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <tool.icon className="w-6 h-6 text-primary" />
                  </div>
                  {tool.popular && (
                    <Badge className="bg-accent text-accent-foreground">
                      Popular
                    </Badge>
                  )}
                </div>

                {/* Info */}
                <h3 className="text-lg font-semibold mb-1 group-hover:text-primary transition-colors">
                  {tool.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {tool.category}
                </p>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {tool.description}
                </p>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-accent fill-accent" />
                    <span className="text-sm font-medium">{tool.rating}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    ({tool.reviews.toLocaleString()} reviews)
                  </span>
                </div>

                {/* Price */}
                <div className="text-lg font-semibold text-primary mb-4">
                  {tool.price}
                </div>

                {/* Features */}
                <ul className="space-y-1 mb-6">
                  {tool.features.slice(0, 3).map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <Button
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 group/btn"
                  onClick={() => {
                    toast.success(`Redirigiendo a ${tool.name}...`);
                    window.open(tool.affiliateLink, '_blank');
                  }}
                >
                  Probar Ahora
                  <ExternalLink className="w-4 h-4 ml-2 group-hover/btn:translate-x-0.5 transition-transform" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Affiliate Disclaimer */}
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground">
            Algunos enlaces son de afiliados. Si compras a través de ellos, 
            recibimos una pequeña comisión sin costo adicional para ti. Solo recomendamos herramientas que usamos y confiamos.
          </p>
        </div>
      </div>
    </section>
  );
}
