import { useEffect, useState, useRef } from 'react';
import { 
  Users, 
  DollarSign, 
  Globe, 
  TrendingUp,
  Award,
  Zap,
  Target,
  Clock,
  Star,
  CheckCircle2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Stat {
  icon: React.ElementType;
  value: number;
  suffix: string;
  prefix?: string;
  label: string;
  description: string;
}

const stats: Stat[] = [
  {
    icon: Users,
    value: 2500000,
    suffix: '+',
    label: 'Usuarios Activos',
    description: 'Personas ganando dinero con nuestros métodos'
  },
  {
    icon: DollarSign,
    value: 150,
    suffix: 'M+',
    prefix: '$',
    label: 'Dólares Generados',
    description: 'Total ganado por nuestra comunidad'
  },
  {
    icon: Globe,
    value: 180,
    suffix: '+',
    label: 'Países',
    description: 'Alcance global de nuestros métodos'
  },
  {
    icon: TrendingUp,
    value: 94,
    suffix: '%',
    label: 'Tasa de Éxito',
    description: 'Usuarios que generan ingresos consistentes'
  }
];

const additionalStats = [
  { label: 'Métodos Disponibles', value: '28', icon: Target },
  { label: 'Herramientas Recomendadas', value: '50+', icon: Zap },
  { label: 'Artículos del Blog', value: '200+', icon: Award },
  { label: 'Soporte 24/7', value: 'Siempre', icon: Clock },
];

const testimonials = [
  {
    name: 'María G.',
    country: 'México',
    method: 'Freelancing',
    earnings: '$4,500/mes',
    quote: 'Dejé mi trabajo en 3 meses. Ahora trabajo desde casa con clientes de todo el mundo.',
    avatar: 'MG'
  },
  {
    name: 'Carlos R.',
    country: 'España',
    method: 'YouTube',
    earnings: '$8,200/mes',
    quote: 'Empecé como hobby y ahora es mi ingreso principal. La paciencia vale la pena.',
    avatar: 'CR'
  },
  {
    name: 'Ana L.',
    country: 'Colombia',
    method: 'Dropshipping',
    earnings: '$12,000/mes',
    quote: 'Mi tienda factura más de lo que soñé. El método funciona si lo aplicas bien.',
    avatar: 'AL'
  }
];

function AnimatedCounter({ value, prefix = '', suffix = '', duration = 2000 }: { 
  value: number; 
  prefix?: string; 
  suffix?: string; 
  duration?: number;
}) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setCount(Math.floor(easeOutQuart * value));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [isVisible, value, duration]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(num % 1000000 === 0 ? 0 : 1);
    }
    return num.toLocaleString();
  };

  return (
    <span ref={ref} className="tabular-nums">
      {prefix}{formatNumber(count)}{suffix}
    </span>
  );
}

export function Stats() {
  return (
    <section id="stats" className="py-24 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Award className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">Resultados Reales</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Números que{' '}
            <span className="text-gradient-gold">hablan por sí solos</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Miles de personas ya han transformado sus vidas financieras con nuestros métodos probados.
          </p>
        </div>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="relative group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="bg-card/80 backdrop-blur-sm rounded-2xl border border-border/50 p-8 text-center hover-lift glow-green">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                  <stat.icon className="w-7 h-7 text-primary" />
                </div>
                <div className="text-4xl sm:text-5xl font-bold text-foreground mb-2">
                  <AnimatedCounter 
                    value={stat.value} 
                    prefix={stat.prefix} 
                    suffix={stat.suffix}
                  />
                </div>
                <div className="text-lg font-semibold text-foreground mb-1">
                  {stat.label}
                </div>
                <div className="text-sm text-muted-foreground">
                  {stat.description}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {additionalStats.map((stat, index) => (
            <div key={index} className="bg-card/50 rounded-xl p-6 text-center border border-border/30">
              <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-center mb-8">
            Historias de <span className="text-gradient">éxito</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-card rounded-2xl border border-border/50 p-6 hover-lift">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.country}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-4 h-4 text-accent fill-accent" />
                  <Star className="w-4 h-4 text-accent fill-accent" />
                  <Star className="w-4 h-4 text-accent fill-accent" />
                  <Star className="w-4 h-4 text-accent fill-accent" />
                  <Star className="w-4 h-4 text-accent fill-accent" />
                </div>
                <p className="text-muted-foreground mb-4 text-sm">"{testimonial.quote}"</p>
                <div className="flex items-center justify-between">
                  <Badge variant="outline">{testimonial.method}</Badge>
                  <span className="text-primary font-semibold">{testimonial.earnings}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Features Banner */}
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10 rounded-3xl border border-primary/20 p-8 lg:p-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-5 h-5 text-accent" />
                <span className="text-sm text-accent font-medium">¿Por qué nosotros?</span>
              </div>
              <h3 className="text-2xl lg:text-3xl font-bold mb-4">
                Todo lo que necesitas para{' '}
                <span className="text-gradient">tener éxito</span>
              </h3>
              <p className="text-muted-foreground mb-6">
                No solo te damos una lista de métodos. Te proporcionamos herramientas, 
                calculadoras, tests de perfil y una comunidad que te apoya en cada paso.
              </p>
              <div className="flex flex-wrap gap-3">
                {['Métodos Verificados', 'Soporte 24/7', 'Actualizaciones', 'Comunidad Activa', 'Garantía'].map((item) => (
                  <span
                    key={item}
                    className="px-4 py-2 rounded-full bg-background/50 border border-border text-sm text-foreground flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3 h-3 text-primary" />
                    {item}
                  </span>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-card/50 rounded-xl p-6 text-center border border-border/50">
                <div className="text-3xl font-bold text-primary mb-1">0$</div>
                <div className="text-sm text-muted-foreground">Costo inicial</div>
              </div>
              <div className="bg-card/50 rounded-xl p-6 text-center border border-border/50">
                <div className="text-3xl font-bold text-accent mb-1">100%</div>
                <div className="text-sm text-muted-foreground">Gratuito empezar</div>
              </div>
              <div className="bg-card/50 rounded-xl p-6 text-center border border-border/50">
                <div className="text-3xl font-bold text-primary mb-1">28</div>
                <div className="text-sm text-muted-foreground">Métodos</div>
              </div>
              <div className="bg-card/50 rounded-xl p-6 text-center border border-border/50">
                <div className="text-3xl font-bold text-accent mb-1">24/7</div>
                <div className="text-sm text-muted-foreground">Disponible</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
