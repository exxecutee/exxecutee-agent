import { useState } from 'react';
import { 
  Laptop, TrendingUp, PenTool, Code, ShoppingBag, 
  Headphones, BarChart3, Mic, BookOpen, Palette, Video,
  Smartphone, Globe, Car, Home, Gamepad2, Bitcoin,
  Briefcase, MessageSquare, Music, Image as ImageIcon,
  Search, Award, ArrowRight, Clock, DollarSign,
  Star, Filter, Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Method {
  id: number;
  title: string;
  description: string;
  longDescription: string;
  icon: React.ElementType;
  category: string;
  difficulty: 'Fácil' | 'Medio' | 'Avanzado';
  earnings: string;
  timeToFirst: string;
  startupCost: string;
  rating: number;
  reviews: number;
  tags: string[];
  steps: string[];
  platforms: string[];
  pros: string[];
  cons: string[];
  featured?: boolean;
}

const methods: Method[] = [
  {
    id: 1,
    title: 'Freelancing General',
    description: 'Ofrece tus habilidades en plataformas globales. Desde diseño hasta programación.',
    longDescription: 'El freelancing te permite trabajar desde cualquier lugar del mundo ofreciendo tus habilidades a clientes globales. Puedes empezar con cero inversión y escalar tus ingresos según tu experiencia.',
    icon: Laptop,
    category: 'Servicios',
    difficulty: 'Medio',
    earnings: '$1,000 - $15,000/mes',
    timeToFirst: '1-2 semanas',
    startupCost: '$0 - $100',
    rating: 4.8,
    reviews: 12543,
    tags: ['Remoto', 'Flexible', 'Alto potencial', 'Escalable'],
    steps: ['Crea tu perfil profesional', 'Define tus servicios y tarifas', 'Envía propuestas a clientes', 'Entrega trabajo de calidad', 'Solicita reseñas positivas'],
    platforms: ['Upwork', 'Fiverr', 'Freelancer', 'Toptal'],
    pros: ['Flexibilidad total de horario', 'Trabaja desde cualquier lugar', 'Ingresos potencialmente altos', 'Variedad de proyectos'],
    cons: ['Competencia alta', 'Ingresos inconsistentes al inicio', 'Necesitas marketing personal'],
    featured: true
  },
  {
    id: 2,
    title: 'Trading de Criptomonedas',
    description: 'Invierte y opera con Bitcoin, Ethereum y altcoins. Alto riesgo, alto retorno.',
    longDescription: 'El trading de criptomonedas permite obtener ganancias significativas operando en mercados volátiles. Requiere educación, disciplina y gestión de riesgos.',
    icon: Bitcoin,
    category: 'Inversión',
    difficulty: 'Avanzado',
    earnings: '$500 - $10,000/mes',
    timeToFirst: 'Inmediato',
    startupCost: '$100 - $10,000+',
    rating: 4.3,
    reviews: 8932,
    tags: ['Alto riesgo', 'Alto retorno', '24/7', 'Volátil'],
    steps: ['Aprende análisis técnico', 'Elige un exchange confiable', 'Empieza con capital que puedas perder', 'Usa stop-loss siempre', 'Mantén un diario de trading'],
    platforms: ['Binance', 'Coinbase', 'Kraken', 'Bybit'],
    pros: ['Mercado 24/7', 'Alta liquidez', 'Potencial de grandes ganancias', 'Bajas barreras de entrada'],
    cons: ['Muy volátil', 'Riesgo de perder capital', 'Requiere constante aprendizaje', 'Estresante emocionalmente']
  },
  {
    id: 3,
    title: 'YouTube Content Creator',
    description: 'Crea videos y monetiza con ads, patrocinios y membresías.',
    longDescription: 'YouTube ofrece múltiples fuentes de ingresos: publicidad, Super Chats, membresías, mercancía y patrocinios. Requiere consistencia y calidad de contenido.',
    icon: Video,
    category: 'Creativo',
    difficulty: 'Medio',
    earnings: '$500 - $100,000+/mes',
    timeToFirst: '6-12 meses',
    startupCost: '$0 - $2,000',
    rating: 4.7,
    reviews: 22156,
    tags: ['Creativo', 'Escalable', 'Pasivo', 'Largo plazo'],
    steps: ['Elige tu nicho', 'Crea contenido consistente', 'Optimiza SEO', 'Llega a 1,000 suscriptores', 'Aplica al Programa de Partners'],
    platforms: ['YouTube', 'TubeBuddy', 'VidIQ'],
    pros: ['Ingresos pasivos', 'Audiencia global', 'Múltiples fuentes de ingreso', 'Construyes marca personal'],
    cons: ['Tarda en generar ingresos', 'Requiere equipo inicial', 'Algoritmo impredecible', 'Competencia intensa'],
    featured: true
  },
  {
    id: 4,
    title: 'Copywriting Profesional',
    description: 'Escribe textos persuasivos que venden. Emails, landing pages, anuncios.',
    longDescription: 'Los copywriters ganan muy bien escribiendo textos que convierten visitantes en clientes. Es una habilidad de alta demanda y bien remunerada.',
    icon: PenTool,
    category: 'Escritura',
    difficulty: 'Fácil',
    earnings: '$2,000 - $12,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$0',
    rating: 4.6,
    reviews: 7654,
    tags: ['Remoto', 'Alta demanda', 'Flexible', 'Bajo costo'],
    steps: ['Aprende copywriting persuasivo', 'Crea un portafolio', 'Ofrece servicios en freelance', 'Especialízate en un nicho', 'Aumenta tus tarifas'],
    platforms: ['Upwork', 'Fiverr', 'Contently', 'ProBlogger'],
    pros: ['Alta demanda constante', 'Puedes trabajar desde casa', 'Buenos ingresos', 'Mejora con la práctica'],
    cons: ['Requiere creatividad constante', 'Feedback subjetivo', 'Plazos ajustados']
  },
  {
    id: 5,
    title: 'Desarrollo Web & Apps',
    description: 'Crea sitios web y aplicaciones móviles para clientes globales.',
    longDescription: 'Los desarrolladores web y móviles están en alta demanda. Puedes cobrar desde $50 hasta $500+ por hora según tu especialización.',
    icon: Code,
    category: 'Tecnología',
    difficulty: 'Avanzado',
    earnings: '$3,000 - $20,000/mes',
    timeToFirst: '1-3 meses',
    startupCost: '$0 - $500',
    rating: 4.9,
    reviews: 15678,
    tags: ['Alto valor', 'Remoto', 'Estable', 'Escalable'],
    steps: ['Aprende a programar', 'Construye proyectos personales', 'Crea portafolio en GitHub', 'Aplica a trabajos freelance', 'Especialízate'],
    platforms: ['GitHub', 'Upwork', 'Toptal', 'Stack Overflow Jobs'],
    pros: ['Muy bien pagado', 'Alta demanda global', 'Trabajo remoto', 'Constante aprendizaje'],
    cons: ['Curva de aprendizaje empinada', 'Tecnología cambia rápido', 'Puede ser estresante'],
    featured: true
  },
  {
    id: 6,
    title: 'Dropshipping',
    description: 'Vende productos sin inventario. El proveedor envía directo al cliente.',
    longDescription: 'El dropshipping te permite tener una tienda online sin manejar inventario. Tu proveedor envía los productos directamente a tus clientes.',
    icon: ShoppingBag,
    category: 'E-commerce',
    difficulty: 'Medio',
    earnings: '$1,000 - $50,000/mes',
    timeToFirst: '2-6 semanas',
    startupCost: '$100 - $1,000',
    rating: 4.2,
    reviews: 18765,
    tags: ['E-commerce', 'Escalable', 'Automatizable', 'Sin inventario'],
    steps: ['Elige tu nicho', 'Encuentra proveedores', 'Crea tu tienda Shopify', 'Configura anuncios', 'Optimiza conversiones'],
    platforms: ['Shopify', 'AliExpress', 'Oberlo', 'Facebook Ads'],
    pros: ['Sin inventario', 'Bajo riesgo inicial', 'Escalable', 'Automatizable'],
    cons: ['Márgenes bajos', 'Competencia alta', 'Dependencia de proveedores', 'Costo de ads']
  },
  {
    id: 7,
    title: 'Consultoría Online',
    description: 'Asesora empresas o individuos en tu área de expertise.',
    longDescription: 'Si tienes conocimientos especializados, puedes cobrar por asesorar a otros. Desde marketing hasta finanzas personales.',
    icon: Headphones,
    category: 'Servicios',
    difficulty: 'Medio',
    earnings: '$2,000 - $15,000/mes',
    timeToFirst: '2-6 semanas',
    startupCost: '$0 - $200',
    rating: 4.7,
    reviews: 5432,
    tags: ['Alto valor', 'Flexible', 'Profesional', 'Experiencia'],
    steps: ['Define tu expertise', 'Crea paquetes de consultoría', 'Construye presencia online', 'Consigue primeros clientes', 'Pide referencias'],
    platforms: ['Clarity.fm', 'Upwork', 'LinkedIn', 'Calendly'],
    pros: ['Muy bien pagado', 'Usa tu conocimiento', 'Horario flexible', 'Impacto real'],
    cons: ['Requiere credibilidad', 'Necesitas experiencia previa', 'Responsabilidad alta']
  },
  {
    id: 8,
    title: 'Affiliate Marketing',
    description: 'Promociona productos y gana comisiones por cada venta.',
    longDescription: 'Gana dinero recomendando productos que usas. Cada vez que alguien compra con tu link, recibes una comisión.',
    icon: BarChart3,
    category: 'Marketing',
    difficulty: 'Fácil',
    earnings: '$500 - $20,000/mes',
    timeToFirst: '1-3 meses',
    startupCost: '$0 - $100',
    rating: 4.4,
    reviews: 14321,
    tags: ['Pasivo', 'Escalable', 'Bajo costo', 'Flexible'],
    steps: ['Elige nicho rentable', 'Únete a programas de afiliados', 'Crea contenido de valor', 'Inserta links de afiliado', 'Escala tu tráfico'],
    platforms: ['Amazon Associates', 'ShareASale', 'ClickBank', 'CJ Affiliate'],
    pros: ['Ingresos pasivos', 'Sin producto propio', 'Flexible', 'Escalable'],
    cons: ['Tarda en generar ingresos', 'Dependencia de plataformas', 'Competencia alta']
  },
  {
    id: 9,
    title: 'Podcasting',
    description: 'Crea un podcast y monetiza con patrocinios y donaciones.',
    longDescription: 'Los podcasts están creciendo exponencialmente. Puedes monetizar con publicidad, Patreon, y productos relacionados.',
    icon: Mic,
    category: 'Creativo',
    difficulty: 'Medio',
    earnings: '$500 - $30,000/mes',
    timeToFirst: '3-6 meses',
    startupCost: '$100 - $500',
    rating: 4.5,
    reviews: 6789,
    tags: ['Creativo', 'Comunidad', 'Escalable', 'Pasivo'],
    steps: ['Elige tema y formato', 'Compra equipo básico', 'Graba y edita episodios', 'Publica en plataformas', 'Busca patrocinadores'],
    platforms: ['Anchor', 'Spotify', 'Apple Podcasts', 'Buzzsprout'],
    pros: ['Construye audiencia leal', 'Múltiples ingresos', 'Networking', 'Creativo'],
    cons: ['Requiere consistencia', 'Equipo inicial', 'Tarda en monetizar']
  },
  {
    id: 10,
    title: 'Ebooks & Cursos Online',
    description: 'Crea y vende contenido educativo digital. Ingresos pasivos.',
    longDescription: 'Empaqueta tu conocimiento en ebooks o cursos. Una vez creados, generan ingresos pasivos continuamente.',
    icon: BookOpen,
    category: 'Educación',
    difficulty: 'Medio',
    earnings: '$1,000 - $25,000/mes',
    timeToFirst: '2-4 meses',
    startupCost: '$0 - $500',
    rating: 4.8,
    reviews: 9876,
    tags: ['Pasivo', 'Escalable', 'Educación', 'Producto digital'],
    steps: ['Elige tema de expertise', 'Crea contenido valioso', 'Elige plataforma', 'Configura ventas', 'Marketing continuo'],
    platforms: ['Udemy', 'Teachable', 'Gumroad', 'Amazon KDP'],
    pros: ['Ingresos pasivos', 'Sin inventario', 'Escalable', 'Ayudas a otros'],
    cons: ['Tarda en crear', 'Marketing necesario', 'Competencia'],
    featured: true
  },
  {
    id: 11,
    title: 'Diseño Gráfico',
    description: 'Crea logos, branding, y diseños visuales para clientes.',
    longDescription: 'Los diseñadores gráficos siempre están en demanda. Desde logos hasta diseño completo de marca.',
    icon: Palette,
    category: 'Creativo',
    difficulty: 'Medio',
    earnings: '$1,500 - $10,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$0 - $1,000',
    rating: 4.6,
    reviews: 11234,
    tags: ['Creativo', 'Remoto', 'Flexible', 'Alta demanda'],
    steps: ['Aprende herramientas', 'Crea portafolio', 'Define servicios', 'Busca clientes', 'Especialízate'],
    platforms: ['99designs', 'Dribbble', 'Behance', 'Fiverr'],
    pros: ['Creativo', 'Bien pagado', 'Flexible', 'Demanda constante'],
    cons: ['Software costoso', 'Clientes difíciles', 'Revisiones múltiples']
  },
  {
    id: 12,
    title: 'TikTok Creator',
    description: 'Crea contenido viral en TikTok y monetiza con el Creator Fund.',
    longDescription: 'TikTok ofrece múltiples formas de ganar dinero: Creator Fund, lives, regalos, y patrocinios de marcas.',
    icon: Smartphone,
    category: 'Creativo',
    difficulty: 'Fácil',
    earnings: '$500 - $50,000/mes',
    timeToFirst: '1-3 meses',
    startupCost: '$0',
    rating: 4.5,
    reviews: 25678,
    tags: ['Viral', 'Joven', 'Rápido', 'Creativo'],
    steps: ['Crea cuenta', 'Publica consistentemente', 'Sigue tendencias', 'Llega a 10K seguidores', 'Aplica al Creator Fund'],
    platforms: ['TikTok', 'CapCut', 'TrendTok'],
    pros: ['Gratis empezar', 'Viral potencial', 'Joven audiencia', 'Rápido crecimiento'],
    cons: ['Algoritmo impredecible', 'Contenido efímero', 'Competencia intensa']
  },
  {
    id: 13,
    title: 'Blogging Profesional',
    description: 'Crea un blog y monetiza con ads, afiliados y productos propios.',
    longDescription: 'El blogging sigue siendo una de las formas más estables de generar ingresos pasivos online a largo plazo.',
    icon: Globe,
    category: 'Escritura',
    difficulty: 'Medio',
    earnings: '$1,000 - $30,000/mes',
    timeToFirst: '6-12 meses',
    startupCost: '$50 - $200',
    rating: 4.7,
    reviews: 19876,
    tags: ['Pasivo', 'Largo plazo', 'SEO', 'Escalable'],
    steps: ['Elige nicho rentable', 'Configura WordPress', 'Crea contenido SEO', 'Construye audiencia', 'Monetiza'],
    platforms: ['WordPress', 'Bluehost', 'Google AdSense', 'Mediavine'],
    pros: ['Ingresos pasivos', 'Activo digital', 'Escalable', 'Autoridad'],
    cons: ['Tarda en ver resultados', 'Requiere SEO', 'Competencia'],
    featured: true
  },
  {
    id: 14,
    title: 'Conductor Uber/Delivery',
    description: 'Gana dinero conduciendo o haciendo entregas con tu vehículo.',
    longDescription: 'Plataformas como Uber, DoorDash y Rappi te permiten ganar dinero inmediatamente con tu vehículo.',
    icon: Car,
    category: 'Servicios',
    difficulty: 'Fácil',
    earnings: '$500 - $3,000/mes',
    timeToFirst: '1 semana',
    startupCost: '$0',
    rating: 4.2,
    reviews: 45678,
    tags: ['Inmediato', 'Flexible', 'Físico', 'Rápido'],
    steps: ['Regístrate en app', 'Verifica documentos', 'Activa tu cuenta', 'Empieza a aceptar viajes', 'Maximiza horas pico'],
    platforms: ['Uber', 'Lyft', 'DoorDash', 'Uber Eats'],
    pros: ['Empieza rápido', 'Flexible', 'Pagos semanales', 'Sin jefe'],
    cons: ['Desgaste vehículo', 'Gastos de gas', 'Riesgo accidentes', 'Ingresos variables']
  },
  {
    id: 15,
    title: 'Airbnb Hosting',
    description: 'Alquila tu espacio extra o propiedades en Airbnb.',
    longDescription: 'Si tienes espacio extra, puedes generar ingresos significativos alquilándolo en Airbnb u otras plataformas.',
    icon: Home,
    category: 'Propiedades',
    difficulty: 'Medio',
    earnings: '$500 - $10,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$0 - $5,000',
    rating: 4.6,
    reviews: 34567,
    tags: ['Pasivo', 'Propiedades', 'Turismo', 'Escalable'],
    steps: ['Prepara tu espacio', 'Crea listing atractivo', 'Toma fotos profesionales', 'Define precios', 'Gestiona reservas'],
    platforms: ['Airbnb', 'Vrbo', 'Booking.com'],
    pros: ['Buenos ingresos', 'Conoces gente', 'Flexible', 'Escalable'],
    cons: ['Requiere mantenimiento', 'Huéspedes problemáticos', 'Regulaciones locales']
  },
  {
    id: 16,
    title: 'Streaming de Videojuegos',
    description: 'Transmite tus partidas en Twitch/YouTube y gana con suscripciones.',
    longDescription: 'Los gamers pueden ganar dinero transmitiendo en Twitch, YouTube Gaming o Facebook Gaming.',
    icon: Gamepad2,
    category: 'Entretenimiento',
    difficulty: 'Medio',
    earnings: '$500 - $50,000/mes',
    timeToFirst: '3-6 meses',
    startupCost: '$500 - $2,000',
    rating: 4.4,
    reviews: 23456,
    tags: ['Gaming', 'Entretenimiento', 'Comunidad', 'Joven'],
    steps: ['Elige plataforma', 'Configura equipo', 'Define horario', 'Interactúa con viewers', 'Monetiza'],
    platforms: ['Twitch', 'YouTube Gaming', 'Facebook Gaming'],
    pros: ['Haces lo que te gusta', 'Comunidad leal', 'Múltiples ingresos', 'Divertido'],
    cons: ['Muy competitivo', 'Requiere carisma', 'Horarios largos', 'Equipo costoso']
  },
  {
    id: 17,
    title: 'Trading Forex',
    description: 'Opera en el mercado de divisas internacional.',
    longDescription: 'El Forex es el mercado más grande del mundo. Operas pares de divisas buscando ganancias por fluctuaciones.',
    icon: TrendingUp,
    category: 'Inversión',
    difficulty: 'Avanzado',
    earnings: '$1,000 - $20,000/mes',
    timeToFirst: 'Inmediato',
    startupCost: '$500 - $10,000',
    rating: 4.1,
    reviews: 8765,
    tags: ['Alto riesgo', 'Alto retorno', '24/5', 'Global'],
    steps: ['Aprende análisis técnico', 'Elige broker regulado', 'Practica en demo', 'Empieza con capital pequeño', 'Gestiona riesgo'],
    platforms: ['MetaTrader', 'eToro', 'IG', 'OANDA'],
    pros: ['Mercado 24/5', 'Alta liquidez', 'Apalancamiento', 'Global'],
    cons: ['Muy riesgoso', 'Requiere disciplina', 'Brokers no regulados', 'Pérdidas rápidas']
  },
  {
    id: 18,
    title: 'Virtual Assistant',
    description: 'Asiste a empresarios y empresas con tareas administrativas remotas.',
    longDescription: 'Los asistentes virtuales son esenciales para empresarios ocupados. Gestión de emails, calendarios, redes sociales y más.',
    icon: Briefcase,
    category: 'Servicios',
    difficulty: 'Fácil',
    earnings: '$1,000 - $5,000/mes',
    timeToFirst: '1-2 semanas',
    startupCost: '$0',
    rating: 4.5,
    reviews: 12345,
    tags: ['Remoto', 'Flexible', 'Alta demanda', 'Bajo costo'],
    steps: ['Define servicios', 'Crea perfil profesional', 'Busca en job boards', 'Consigue primeros clientes', 'Especialízate'],
    platforms: ['Belay', 'Time Etc', 'Fancy Hands', 'Upwork'],
    pros: ['Alta demanda', 'Flexible', 'Remoto', 'Variedad de tareas'],
    cons: ['Puede ser repetitivo', 'Múltiples jefes', 'Horarios de cliente']
  },
  {
    id: 19,
    title: 'Community Manager',
    description: 'Gestiona redes sociales para empresas y creadores.',
    longDescription: 'Las empresas necesitan presencia en redes sociales. Como CM, creas contenido, respondes comentarios y analizas métricas.',
    icon: MessageSquare,
    category: 'Marketing',
    difficulty: 'Fácil',
    earnings: '$1,000 - $6,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$0 - $100',
    rating: 4.4,
    reviews: 9876,
    tags: ['Redes sociales', 'Creativo', 'Remoto', 'Demanda'],
    steps: ['Aprende plataformas', 'Crea contenido de ejemplo', 'Busca pequeños clientes', 'Mide resultados', 'Escala'],
    platforms: ['Hootsuite', 'Buffer', 'Later', 'Canva'],
    pros: ['Creativo', 'Demanda alta', 'Remoto', 'Aprendes mucho'],
    cons: ['Siempre "conectado"', 'Clientes exigentes', 'Cambios de algoritmo']
  },
  {
    id: 20,
    title: 'Productor Musical',
    description: 'Crea beats y música para artistas, YouTubers y comerciales.',
    longDescription: 'Si tienes talento musical, puedes vender beats, producir para artistas o crear música para contenido.',
    icon: Music,
    category: 'Creativo',
    difficulty: 'Avanzado',
    earnings: '$500 - $15,000/mes',
    timeToFirst: '1-3 meses',
    startupCost: '$500 - $3,000',
    rating: 4.3,
    reviews: 5432,
    tags: ['Musical', 'Creativo', 'Pasivo', 'Artístico'],
    steps: ['Aprende producción', 'Crea beats', 'Sube a plataformas', 'Promociona', 'Colabora'],
    platforms: ['BeatStars', 'Airbit', 'SoundCloud', 'Spotify'],
    pros: ['Creativo', 'Ingresos pasivos', 'Colaboraciones', 'Flexible'],
    cons: ['Software costoso', 'Competencia alta', 'Derechos de autor']
  },
  {
    id: 21,
    title: 'Fotografía Stock',
    description: 'Vende tus fotos en bancos de imágenes una y otra vez.',
    longDescription: 'Sube tus fotos a bancos de imágenes y gana cada vez que alguien las descarga. Ingresos verdaderamente pasivos.',
    icon: ImageIcon,
    category: 'Creativo',
    difficulty: 'Fácil',
    earnings: '$200 - $5,000/mes',
    timeToFirst: '1-2 meses',
    startupCost: '$0 - $1,000',
    rating: 4.2,
    reviews: 7654,
    tags: ['Pasivo', 'Fotografía', 'Creativo', 'Largo plazo'],
    steps: ['Toma fotos de calidad', 'Edita profesionalmente', 'Sube a múltiples plataformas', 'Etiqueta correctamente', 'Sube consistentemente'],
    platforms: ['Shutterstock', 'Adobe Stock', 'iStock', 'Getty'],
    pros: ['Pasivo total', 'Usas tu pasión', 'Escalable', 'Global'],
    cons: ['Bajo pago por foto', 'Mucha competencia', 'Requiere volumen']
  },
  {
    id: 22,
    title: 'SEO Specialist',
    description: 'Ayuda a sitios web a posicionarse en Google y recibir tráfico.',
    longDescription: 'El SEO es crucial para negocios online. Como especialista, optimizas sitios para que aparezcan en búsquedas.',
    icon: Search,
    category: 'Marketing',
    difficulty: 'Avanzado',
    earnings: '$2,000 - $15,000/mes',
    timeToFirst: '1-2 meses',
    startupCost: '$0 - $500',
    rating: 4.7,
    reviews: 6789,
    tags: ['Técnico', 'Alto valor', 'Demanda', 'Remoto'],
    steps: ['Aprende SEO profundo', 'Certifícate', 'Crea casos de estudio', 'Ofrece auditorías', 'Escala servicios'],
    platforms: ['Ahrefs', 'SEMrush', 'Moz', 'Google Search Console'],
    pros: ['Muy bien pagado', 'Demanda creciente', 'Remoto', 'Resultados medibles'],
    cons: ['Cambia constantemente', 'Técnico', 'Resultados tardan']
  },
  {
    id: 23,
    title: 'Gestión de Anuncios (PPC)',
    description: 'Administra campañas publicitarias en Facebook, Google y más.',
    longDescription: 'Las empresas pagan bien por alguien que gestione sus anuncios efectivamente. Es una habilidad de alto valor.',
    icon: Award,
    category: 'Marketing',
    difficulty: 'Medio',
    earnings: '$2,000 - $12,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$0 - $200',
    rating: 4.6,
    reviews: 8765,
    tags: ['Alto valor', 'Técnico', 'Demanda', 'Escalable'],
    steps: ['Aprende plataformas', 'Certifícate en Google/Facebook', 'Practica con tu propio dinero', 'Consigue primeros clientes', 'Muestra ROI'],
    platforms: ['Facebook Ads', 'Google Ads', 'TikTok Ads', 'LinkedIn Ads'],
    pros: ['Muy bien pagado', 'Resultados claros', 'Demanda constante', 'Escalable'],
    cons: ['Presión de resultados', 'Pérdida de dinero cliente', 'Competencia']
  },
  {
    id: 24,
    title: 'Membresías & Suscripciones',
    description: 'Crea contenido exclusivo para suscriptores de pago.',
    longDescription: 'Plataformas como Patreon y OnlyFans (no solo adulto) permiten monetizar contenido exclusivo mediante suscripciones mensuales.',
    icon: Users,
    category: 'Creativo',
    difficulty: 'Medio',
    earnings: '$500 - $50,000/mes',
    timeToFirst: '1-3 meses',
    startupCost: '$0',
    rating: 4.5,
    reviews: 15678,
    tags: ['Recurrente', 'Comunidad', 'Escalable', 'Pasivo'],
    steps: ['Define tu contenido exclusivo', 'Elige plataforma', 'Crea tiers de membresía', 'Promociona', 'Entrega valor constante'],
    platforms: ['Patreon', 'OnlyFans', 'Substack', 'Ko-fi'],
    pros: ['Ingresos recurrentes', 'Comunidad leal', 'Flexible', 'Escalable'],
    cons: ['Presión de contenido', 'Plataformas toman comisión', 'Estigma algunas plataformas']
  },
  {
    id: 25,
    title: 'Flipping de Productos',
    description: 'Compra barato, vende caro. Desde ropa hasta electrónica.',
    longDescription: 'Encuentra productos subvalorados en tiendas de segunda mano, outlet o liquidaciones y revéndelos con margen.',
    icon: ShoppingBag,
    category: 'E-commerce',
    difficulty: 'Fácil',
    earnings: '$500 - $5,000/mes',
    timeToFirst: '1-2 semanas',
    startupCost: '$100 - $1,000',
    rating: 4.3,
    reviews: 11234,
    tags: ['Físico', 'Flexible', 'Rápido', 'Escalable'],
    steps: ['Investiga productos rentables', 'Encuentra fuentes', 'Compra bajo', 'Lista en marketplaces', 'Repite'],
    platforms: ['eBay', 'Facebook Marketplace', 'Mercari', 'Poshmark'],
    pros: ['Rápido empezar', 'Cash rápido', 'Flexible', 'Aprendes negocios'],
    cons: ['Requiere espacio', 'Inventario físico', 'Tiempo de envío', 'Estafas']
  },
  {
    id: 26,
    title: 'Influencer Marketing',
    description: 'Construye audiencia y colabora con marcas por dinero.',
    longDescription: 'Con una audiencia comprometida en cualquier plataforma, las marcas pagarán por promociones y colaboraciones.',
    icon: Award,
    category: 'Marketing',
    difficulty: 'Medio',
    earnings: '$1,000 - $100,000+/mes',
    timeToFirst: '3-6 meses',
    startupCost: '$0 - $500',
    rating: 4.6,
    reviews: 19876,
    tags: ['Social', 'Escalable', 'Creativo', 'Alto potencial'],
    steps: ['Elige nicho', 'Crea contenido consistente', 'Crece audiencia', 'Contacta marcas', 'Negocia colaboraciones'],
    platforms: ['Instagram', 'TikTok', 'YouTube', 'Twitter'],
    pros: ['Alto potencial', 'Creativo', 'Viajes/eventos', 'Productos gratis'],
    cons: ['Presión de audiencia', 'Privacidad reducida', 'Ingresos variables', 'Algoritmos']
  },
  {
    id: 27,
    title: 'Desarrollo de Apps Móviles',
    description: 'Crea aplicaciones para iOS y Android.',
    longDescription: 'Las apps móviles pueden generar millones. Desde juegos hasta herramientas de productividad.',
    icon: Smartphone,
    category: 'Tecnología',
    difficulty: 'Avanzado',
    earnings: '$2,000 - $100,000+/mes',
    timeToFirst: '3-6 meses',
    startupCost: '$500 - $5,000',
    rating: 4.8,
    reviews: 7654,
    tags: ['Técnico', 'Escalable', 'Pasivo', 'Alto potencial'],
    steps: ['Aprende Swift/Kotlin', 'Identifica necesidad', 'Desarrolla MVP', 'Publica en stores', 'Itera y mejora'],
    platforms: ['App Store', 'Google Play', 'Flutter', 'React Native'],
    pros: ['Escalable masivo', 'Ingresos pasivos', 'Global', 'Alto potencial'],
    cons: ['Muy técnico', 'Competencia feroz', 'Costoso desarrollar', 'Marketing difícil']
  },
  {
    id: 28,
    title: 'Voice Over & Narración',
    description: 'Presta tu voz para comerciales, videos, audiolibros.',
    longDescription: 'Si tienes una buena voz, puedes ganar dinero narrando audiolibros, comerciales, videos explicativos y más.',
    icon: Mic,
    category: 'Creativo',
    difficulty: 'Fácil',
    earnings: '$500 - $8,000/mes',
    timeToFirst: '2-4 semanas',
    startupCost: '$200 - $1,000',
    rating: 4.4,
    reviews: 6543,
    tags: ['Voz', 'Creativo', 'Flexible', 'Remoto'],
    steps: ['Configura home studio', 'Crea demo reel', 'Únete a plataformas', 'Audiciona', 'Entrega calidad'],
    platforms: ['Voices.com', 'ACX', 'Fiverr', 'Voice123'],
    pros: ['Flexible', 'Creativo', 'Remoto', 'Buenos ingresos'],
    cons: ['Equipo inicial', 'Competencia', 'Voz puede cansarse']
  }
];

const categories = ['Todos', 'Servicios', 'Inversión', 'Creativo', 'Escritura', 'Tecnología', 'E-commerce', 'Marketing', 'Educación', 'Propiedades', 'Entretenimiento'];

const difficultyColors = {
  'Fácil': 'bg-green-500/20 text-green-400 border-green-500/30',
  'Medio': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'Avanzado': 'bg-red-500/20 text-red-400 border-red-500/30'
};

export function Methods() {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [selectedMethod, setSelectedMethod] = useState<Method | null>(null);
  const [showFeaturedOnly, setShowFeaturedOnly] = useState(false);

  const filteredMethods = methods.filter(m => {
    if (showFeaturedOnly && !m.featured) return false;
    if (activeCategory === 'Todos') return true;
    return m.category === activeCategory;
  });

  const featuredMethods = methods.filter(m => m.featured);

  return (
    <section id="methods" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 border-primary/30 text-primary">
            28 Métodos Verificados
          </Badge>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Elige tu camino para{' '}
            <span className="text-gradient">generar ingresos</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Cada método ha sido probado por miles de personas. Encuentra el que mejor se adapte a tus habilidades, tiempo y objetivos.
          </p>
        </div>

        {/* Featured Methods */}
        {!showFeaturedOnly && activeCategory === 'Todos' && (
          <div className="mb-12">
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Award className="w-5 h-5 text-accent" />
              Métodos Destacados
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredMethods.map((method) => (
                <div
                  key={method.id}
                  onClick={() => setSelectedMethod(method)}
                  className="group cursor-pointer bg-card rounded-2xl border border-primary/30 overflow-hidden hover-lift glow-green relative"
                >
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-accent text-accent-foreground">
                      Destacado
                    </Badge>
                  </div>
                  <div className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <method.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                          {method.title}
                        </h4>
                        <p className="text-sm text-muted-foreground">{method.category}</p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {method.description}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-primary font-medium">{method.earnings}</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-accent fill-accent" />
                        <span>{method.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-8">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={showFeaturedOnly}
              onChange={(e) => setShowFeaturedOnly(e.target.checked)}
              className="rounded border-border text-primary focus:ring-primary"
            />
            <span className="text-sm text-muted-foreground">Solo destacados</span>
          </label>
        </div>

        {/* Methods Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredMethods.map((method, index) => (
            <div
              key={method.id}
              onClick={() => setSelectedMethod(method)}
              className="group cursor-pointer bg-card rounded-2xl border border-border/50 overflow-hidden hover-lift hover:border-primary/50 transition-all"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <method.icon className="w-6 h-6 text-primary" />
                  </div>
                  <Badge variant="outline" className={difficultyColors[method.difficulty]}>
                    {method.difficulty}
                  </Badge>
                </div>

                <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                  {method.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {method.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {method.tags.slice(0, 2).map((tag) => (
                    <span
                      key={tag}
                      className="text-xs px-2 py-1 rounded-full bg-secondary text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Stats */}
                <div className="space-y-2 pt-4 border-t border-border/50">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      Ganancias
                    </span>
                    <span className="text-foreground font-medium">{method.earnings}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Primer pago
                    </span>
                    <span className="text-foreground font-medium">{method.timeToFirst}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Star className="w-4 h-4" />
                      Rating
                    </span>
                    <span className="text-accent font-medium">{method.rating} ({method.reviews.toLocaleString()})</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Results Count */}
        <div className="text-center mt-8 text-muted-foreground">
          Mostrando {filteredMethods.length} de {methods.length} métodos
        </div>
      </div>

      {/* Method Detail Modal */}
      {selectedMethod && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
          onClick={() => setSelectedMethod(null)}
        >
          <div 
            className="bg-card rounded-3xl border border-border max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-6 border-b border-border/50 flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <selectedMethod.icon className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{selectedMethod.title}</h2>
                  <p className="text-muted-foreground">{selectedMethod.category}</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedMethod(null)}
                className="p-2 hover:bg-secondary rounded-lg transition-colors"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-8">
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-secondary/50 rounded-xl p-4 text-center">
                  <DollarSign className="w-5 h-5 text-primary mx-auto mb-2" />
                  <div className="text-sm text-muted-foreground">Ganancias</div>
                  <div className="font-semibold">{selectedMethod.earnings}</div>
                </div>
                <div className="bg-secondary/50 rounded-xl p-4 text-center">
                  <Clock className="w-5 h-5 text-primary mx-auto mb-2" />
                  <div className="text-sm text-muted-foreground">Primer Pago</div>
                  <div className="font-semibold">{selectedMethod.timeToFirst}</div>
                </div>
                <div className="bg-secondary/50 rounded-xl p-4 text-center">
                  <Filter className="w-5 h-5 text-primary mx-auto mb-2" />
                  <div className="text-sm text-muted-foreground">Dificultad</div>
                  <div className="font-semibold">{selectedMethod.difficulty}</div>
                </div>
                <div className="bg-secondary/50 rounded-xl p-4 text-center">
                  <DollarSign className="w-5 h-5 text-primary mx-auto mb-2" />
                  <div className="text-sm text-muted-foreground">Inversión</div>
                  <div className="font-semibold">{selectedMethod.startupCost}</div>
                </div>
              </div>

              {/* Description */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Descripción</h3>
                <p className="text-muted-foreground">{selectedMethod.longDescription}</p>
              </div>

              {/* Steps */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Pasos para Empezar</h3>
                <ol className="space-y-2">
                  {selectedMethod.steps.map((step, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 text-sm text-primary font-medium">
                        {index + 1}
                      </span>
                      <span className="text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Platforms */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Plataformas Recomendadas</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedMethod.platforms.map((platform) => (
                    <span key={platform} className="px-4 py-2 rounded-full bg-secondary text-sm">
                      {platform}
                    </span>
                  ))}
                </div>
              </div>

              {/* Pros & Cons */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-green-400">Pros</h3>
                  <ul className="space-y-2">
                    {selectedMethod.pros.map((pro, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <svg className="w-5 h-5 text-green-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-muted-foreground">{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-red-400">Contras</h3>
                  <ul className="space-y-2">
                    {selectedMethod.cons.map((con, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <svg className="w-5 h-5 text-red-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        <span className="text-muted-foreground">{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* CTA */}
              <div className="flex gap-4 pt-4">
                <Button 
                  className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={() => {
                    toast.success('¡Te has unido al método ' + selectedMethod.title + '!');
                    setSelectedMethod(null);
                  }}
                >
                  Empezar Este Método
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button 
                  variant="outline"
                  className="border-border"
                  onClick={() => setSelectedMethod(null)}
                >
                  Cerrar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
