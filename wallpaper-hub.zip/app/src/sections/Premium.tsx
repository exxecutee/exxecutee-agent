import { useState } from 'react';
import { 
  Crown, Check, Zap, Star, ArrowRight,
  BookOpen, Video, Users, MessageCircle, Gift
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

interface Plan {
  id: string;
  name: string;
  description: string;
  monthlyPrice: number;
  yearlyPrice: number;
  icon: React.ElementType;
  features: string[];
  highlighted?: boolean;
  badge?: string;
}

const plans: Plan[] = [
  {
    id: 'free',
    name: 'Gratis',
    description: 'Perfecto para empezar',
    monthlyPrice: 0,
    yearlyPrice: 0,
    icon: Star,
    features: [
      'Acceso a 10 métodos básicos',
      'Artículos del blog',
      'Calculadora de ingresos',
      'Newsletter mensual',
      'Comunidad básica'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'Para quienes quieren resultados',
    monthlyPrice: 19,
    yearlyPrice: 190,
    icon: Zap,
    features: [
      'Acceso a todos los 28 métodos',
      'Guías detalladas paso a paso',
      'Test de perfil avanzado',
      'Artículos premium ilimitados',
      'Herramientas exclusivas',
      'Soporte prioritario',
      'Actualizaciones mensuales'
    ],
    highlighted: true,
    badge: 'Más Popular'
  },
  {
    id: 'elite',
    name: 'Elite',
    description: 'Para emprendedores serios',
    monthlyPrice: 49,
    yearlyPrice: 490,
    icon: Crown,
    features: [
      'Todo lo de Pro',
      'Mentorías grupales mensuales',
      'Cursos en video completos',
      'Grupo privado de Telegram',
      'Consultoría 1-on-1 (1h/mes)',
      'Scripts y templates',
      'Acceso anticipado a nuevos métodos',
      'Garantía de 30 días'
    ],
    badge: 'Mejor Valor'
  }
];

const testimonials = [
  {
    name: 'Roberto M.',
    role: 'Freelancer',
    content: 'Pasé de $500 a $4,000/mes en 6 meses siguiendo los métodos Pro. Vale cada centavo.',
    plan: 'Pro'
  },
  {
    name: 'Carmen L.',
    role: 'YouTuber',
    content: 'Las mentorías Elite cambiaron mi perspectiva. Ahora tengo 100K suscriptores.',
    plan: 'Elite'
  },
  {
    name: 'Andrés P.',
    role: 'Dropshipper',
    content: 'Las guías paso a paso me ahorraron meses de prueba y error. Mi tienda ya factura $15k/mes.',
    plan: 'Pro'
  }
];

export function Premium() {
  const [isYearly, setIsYearly] = useState(false);

  const handleSubscribe = (planId: string) => {
    if (planId === 'free') {
      toast.success('¡Ya tienes acceso al plan Gratis!');
      return;
    }
    toast.success(`Redirigiendo al pago del plan ${planId}...`);
  };

  return (
    <section id="premium" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-accent/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-primary/10 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Crown className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">Premium</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Desbloquea tu{' '}
            <span className="text-gradient-gold">potencial completo</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Accede a métodos exclusivos, mentorías personales y una comunidad de emprendedores de éxito.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isYearly ? 'text-foreground' : 'text-muted-foreground'}`}>
              Mensual
            </span>
            <Switch
              checked={isYearly}
              onCheckedChange={setIsYearly}
            />
            <span className={`text-sm ${isYearly ? 'text-foreground' : 'text-muted-foreground'}`}>
              Anual
            </span>
            {isYearly && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                Ahorra 2 meses
              </Badge>
            )}
          </div>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-card rounded-3xl border p-8 ${
                plan.highlighted 
                  ? 'border-primary/50 glow-green scale-105 z-10' 
                  : 'border-border/50'
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className={plan.highlighted ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground'}>
                    {plan.badge}
                  </Badge>
                </div>
              )}

              <div className="text-center mb-8">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${
                  plan.highlighted ? 'bg-primary/20' : 'bg-secondary'
                }`}>
                  <plan.icon className={`w-8 h-8 ${plan.highlighted ? 'text-primary' : 'text-muted-foreground'}`} />
                </div>
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <div className="text-center mb-8">
                <div className="text-4xl font-bold">
                  ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                  <span className="text-lg text-muted-foreground font-normal">
                    /{isYearly ? 'año' : 'mes'}
                  </span>
                </div>
                {isYearly && plan.yearlyPrice > 0 && (
                  <p className="text-sm text-green-400 mt-1">
                    Ahorras ${(plan.monthlyPrice * 12) - plan.yearlyPrice}/año
                  </p>
                )}
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <Check className={`w-5 h-5 flex-shrink-0 ${plan.highlighted ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full ${
                  plan.highlighted 
                    ? 'bg-primary text-primary-foreground hover:bg-primary/90' 
                    : 'bg-secondary text-foreground hover:bg-secondary/80'
                }`}
                onClick={() => handleSubscribe(plan.id)}
              >
                {plan.id === 'free' ? 'Comenzar Gratis' : 'Suscribirme'}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="bg-card rounded-3xl border border-border/50 p-8 mb-16">
          <h3 className="text-2xl font-bold text-center mb-8">
            ¿Qué incluye tu suscripción?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-7 h-7 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Guías Detalladas</h4>
              <p className="text-sm text-muted-foreground">Pasos exactos para cada método</p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Video className="w-7 h-7 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Cursos en Video</h4>
              <p className="text-sm text-muted-foreground">Aprende a tu propio ritmo</p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Users className="w-7 h-7 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Comunidad Privada</h4>
              <p className="text-sm text-muted-foreground">Conecta con otros emprendedores</p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-7 h-7 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Soporte Prioritario</h4>
              <p className="text-sm text-muted-foreground">Respuestas en menos de 24h</p>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-center mb-8">
            Lo que dicen nuestros miembros
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-card rounded-2xl border border-border/50 p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-accent fill-accent" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                  <Badge variant="outline">{testimonial.plan}</Badge>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guarantee */}
        <div className="bg-gradient-to-r from-green-500/10 to-green-500/5 rounded-3xl border border-green-500/20 p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
            <Gift className="w-8 h-8 text-green-400" />
          </div>
          <h3 className="text-xl font-bold mb-2">Garantía de 30 Días</h3>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Si no estás satisfecho con tu suscripción en los primeros 30 días, 
            te devolvemos tu dinero. Sin preguntas, sin complicaciones.
          </p>
        </div>
      </div>
    </section>
  );
}
