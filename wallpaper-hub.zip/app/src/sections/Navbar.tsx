import { useState, useEffect } from 'react';
import { Menu, X, DollarSign, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Inicio', href: '#hero' },
    { 
      label: 'Métodos', 
      href: '#methods',
      dropdown: [
        { label: 'Todos los Métodos', href: '#methods' },
        { label: 'Freelancing', href: '#methods' },
        { label: 'Trading', href: '#methods' },
        { label: 'E-commerce', href: '#methods' },
        { label: 'Marketing', href: '#methods' },
      ]
    },
    { label: 'Calculadora', href: '#calculator' },
    { label: 'Herramientas', href: '#tools' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Blog', href: '#blog' },
    { label: 'Premium', href: '#premium' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-background/95 backdrop-blur-xl border-b border-border/50'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
              <DollarSign className="w-5 h-5 text-primary" />
            </div>
            <span className="font-bold text-lg text-foreground">
              Gana<span className="text-primary">Dinero</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <div
                key={link.href}
                className="relative"
                onMouseEnter={() => link.dropdown && setActiveDropdown(link.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <a
                  href={link.href}
                  className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors relative group flex items-center gap-1 rounded-lg hover:bg-secondary/50"
                >
                  {link.label}
                  {link.dropdown && <ChevronDown className="w-4 h-4" />}
                </a>
                
                {/* Dropdown */}
                {link.dropdown && activeDropdown === link.label && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-card rounded-xl border border-border/50 shadow-xl overflow-hidden animate-in fade-in slide-in-from-top-2">
                    {link.dropdown.map((item) => (
                      <a
                        key={item.label}
                        href={item.href}
                        className="block px-4 py-3 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
              Iniciar Sesión
            </Button>
            <Button
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium"
            >
              Comenzar Gratis
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-background/98 backdrop-blur-xl border-b border-border max-h-[80vh] overflow-y-auto">
          <div className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <div key={link.href}>
                <a
                  href={link.href}
                  className="block py-3 px-4 text-foreground hover:bg-secondary rounded-lg transition-colors"
                  onClick={() => !link.dropdown && setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
                {link.dropdown && (
                  <div className="pl-4 space-y-1">
                    {link.dropdown.map((item) => (
                      <a
                        key={item.label}
                        href={item.href}
                        className="block py-2 px-4 text-sm text-muted-foreground hover:text-foreground"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-4 space-y-2">
              <Button variant="outline" className="w-full">
                Iniciar Sesión
              </Button>
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                Comenzar Gratis
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
