import { useState } from 'react';
import { 
  Scale, Check, ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface ComparisonMethod {
  id: string;
  name: string;
  category: string;
  difficulty: 'Fácil' | 'Medio' | 'Avanzado';
  startupCost: string;
  timeToFirst: string;
  earnings: string;
  scalability: number;
  passive: number;
  risk: 'Bajo' | 'Medio' | 'Alto';
  bestFor: string[];
}

const comparisonData: ComparisonMethod[] = [
  {
    id: 'freelancing',
    name: 'Freelancing',
    category: 'Servicios',
    difficulty: 'Medio',
    startupCost: '$0',
    timeToFirst: '1-2 semanas',
    earnings: '$1K-15K/mes',
    scalability: 3,
    passive: 1,
    risk: 'Bajo',
    bestFor: ['Personas con habilidades', 'Quieren flexibilidad', 'Necesitan ingresos rápidos']
  },
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'Contenido',
    difficulty: 'Medio',
    startupCost: '$0-500',
    timeToFirst: '6-12 meses',
    earnings: '$500-100K/mes',
    scalability: 5,
    passive: 5,
    risk: 'Medio',
    bestFor: ['Creativos', 'Pacientes', 'Les gusta crear videos']
  },
  {
    id: 'dropshipping',
    name: 'Dropshipping',
    category: 'E-commerce',
    difficulty: 'Medio',
    startupCost: '$100-1K',
    timeToFirst: '2-6 semanas',
    earnings: '$1K-50K/mes',
    scalability: 4,
    passive: 3,
    risk: 'Medio',
    bestFor: ['Emprendedores', 'Presupuesto para ads', 'Gustan del marketing']
  },
  {
    id: 'trading',
    name: 'Trading Crypto',
    category: 'Inversión',
    difficulty: 'Avanzado',
    startupCost: '$100-10K',
    timeToFirst: 'Inmediato',
    earnings: '$500-10K/mes',
    scalability: 3,
    passive: 2,
    risk: 'Alto',
    bestFor: ['Tolerancia al riesgo', 'Analíticos', 'Disponibilidad 24/7']
  },
  {
    id: 'affiliate',
    name: 'Affiliate Marketing',
    category: 'Marketing',
    difficulty: 'Fácil',
    startupCost: '$0-100',
    timeToFirst: '1-3 meses',
    earnings: '$500-20K/mes',
    scalability: 5,
    passive: 5,
    risk: 'Bajo',
    bestFor: ['Bloggers', 'Influencers', 'Creadores de contenido']
  },
  {
    id: 'development',
    name: 'Desarrollo Web',
    category: 'Tecnología',
    difficulty: 'Avanzado',
    startupCost: '$0-500',
    timeToFirst: '1-3 meses',
    earnings: '$3K-20K/mes',
    scalability: 4,
    passive: 2,
    risk: 'Bajo',
    bestFor: ['Programadores', 'Lógicos', 'Buenos ingresos']
  },
  {
    id: 'copywriting',
    name: 'Copywriting',
    category: 'Escritura',
    difficulty: 'Fácil',
    startupCost: '$0',
    timeToFirst: '2-4 semanas',
    earnings: '$2K-12K/mes',
    scalability: 3,
    passive: 1,
    risk: 'Bajo',
    bestFor: ['Buenos escribiendo', 'Persuasivos', 'Creativos']
  },
  {
    id: 'blogging',
    name: 'Blogging',
    category: 'Escritura',
    difficulty: 'Medio',
    startupCost: '$50-200',
    timeToFirst: '6-12 meses',
    earnings: '$1K-30K/mes',
    scalability: 5,
    passive: 5,
    risk: 'Bajo',
    bestFor: ['Escritores', 'Pacientes', 'Expertos en un tema']
  }
];

export function Comparisons() {
  const [selectedMethods, setSelectedMethods] = useState<string[]>(['freelancing', 'youtube']);

  const toggleMethod = (id: string) => {
    if (selectedMethods.includes(id)) {
      setSelectedMethods(selectedMethods.filter(m => m !== id));
    } else if (selectedMethods.length < 4) {
      setSelectedMethods([...selectedMethods, id]);
    } else {
      toast.error('Máximo 4 métodos para comparar');
    }
  };

  const getSelectedData = () => {
    return comparisonData.filter(m => selectedMethods.includes(m.id));
  };

  const renderStars = (value: number) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <div
            key={star}
            className={`w-2 h-2 rounded-full ${
              star <= value ? 'bg-primary' : 'bg-muted'
            }`}
          />
        ))}
      </div>
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Fácil': return 'text-green-400';
      case 'Medio': return 'text-yellow-400';
      case 'Avanzado': return 'text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Bajo': return 'text-green-400';
      case 'Medio': return 'text-yellow-400';
      case 'Alto': return 'text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <section className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Scale className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Comparador</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Compara métodos{' '}
            <span className="text-gradient">lado a lado</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Selecciona hasta 4 métodos y compara sus características para tomar la mejor decisión.
          </p>
        </div>

        {/* Method Selector */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Selecciona métodos para comparar ({selectedMethods.length}/4)</h3>
          <div className="flex flex-wrap gap-2">
            {comparisonData.map((method) => (
              <button
                key={method.id}
                onClick={() => toggleMethod(method.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedMethods.includes(method.id)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-muted-foreground hover:text-foreground'
                }`}
              >
                {selectedMethods.includes(method.id) && <Check className="w-4 h-4 inline mr-1" />}
                {method.name}
              </button>
            ))}
          </div>
        </div>

        {/* Comparison Table */}
        {selectedMethods.length > 0 && (
          <div className="bg-card rounded-3xl border border-border/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left p-4 font-semibold text-muted-foreground">Criterio</th>
                    {getSelectedData().map((method) => (
                      <th key={method.id} className="text-center p-4 min-w-[150px]">
                        <div className="font-semibold">{method.name}</div>
                        <Badge variant="outline" className="mt-1 text-xs">
                          {method.category}
                        </Badge>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {/* Difficulty */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Dificultad</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4">
                        <span className={getDifficultyColor(method.difficulty)}>
                          {method.difficulty}
                        </span>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Startup Cost */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Costo inicial</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4 font-medium">
                        {method.startupCost}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Time to First */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Primer ingreso</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4">
                        {method.timeToFirst}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Earnings */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Ganancias potenciales</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4 font-medium text-primary">
                        {method.earnings}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Scalability */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Escalabilidad</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4">
                        <div className="flex justify-center">{renderStars(method.scalability)}</div>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Passive */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Potencial pasivo</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4">
                        <div className="flex justify-center">{renderStars(method.passive)}</div>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Risk */}
                  <tr className="border-b border-border/30">
                    <td className="p-4 text-muted-foreground">Nivel de riesgo</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="text-center p-4">
                        <span className={getRiskColor(method.risk)}>
                          {method.risk}
                        </span>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Best For */}
                  <tr>
                    <td className="p-4 text-muted-foreground align-top">Ideal para</td>
                    {getSelectedData().map((method) => (
                      <td key={method.id} className="p-4">
                        <ul className="space-y-1">
                          {method.bestFor.map((item, index) => (
                            <li key={index} className="text-sm text-muted-foreground flex items-start gap-1">
                              <Check className="w-3 h-3 text-primary flex-shrink-0 mt-0.5" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="text-center mt-12">
          <Button
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => {
              toast.success('¡Te hemos enviado una comparación detallada a tu email!');
            }}
          >
            Recibir Comparación Completa
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
