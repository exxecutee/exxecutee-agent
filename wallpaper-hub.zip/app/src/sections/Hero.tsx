import { useEffect, useRef, useState } from 'react';
import { ArrowRight, TrendingUp, Wallet, Target, Users, Star, CheckCircle2, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const x = (clientX / innerWidth - 0.5) * 20;
      const y = (clientY / innerHeight - 0.5) * 20;
      
      const elements = heroRef.current.querySelectorAll('.parallax');
      elements.forEach((el, i) => {
        const factor = (i + 1) * 0.5;
        (el as HTMLElement).style.transform = `translate(${x * factor}px, ${y * factor}px)`;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCount(prev => {
        if (prev >= 2500000) return 2500000;
        return prev + 50000;
      });
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const features = [
    '28 métodos verificados',
    'Calculadora de ingresos',
    'Test de perfil personalizado',
    'Comunidad de 2.5M+ usuarios'
  ];

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Orbs */}
        <div className="parallax absolute top-1/4 -left-32 w-96 h-96 bg-primary/20 rounded-full blur-[120px] animate-pulse-glow" />
        <div className="parallax absolute bottom-1/4 -right-32 w-96 h-96 bg-accent/10 rounded-full blur-[120px] animate-pulse-glow" style={{ animationDelay: '1s' }} />
        <div className="parallax absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[150px]" />
        
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(hsl(142 76% 45%) 1px, transparent 1px), linear-gradient(90deg, hsl(142 76% 45%) 1px, transparent 1px)`,
            backgroundSize: '60px 60px'
          }}
        />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-[10%] bg-card/80 backdrop-blur-sm rounded-2xl p-4 border border-border/50 animate-float">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <div className="text-sm font-medium">+$2,450</div>
              <div className="text-xs text-muted-foreground">Este mes</div>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-1/3 left-[5%] bg-card/80 backdrop-blur-sm rounded-2xl p-4 border border-border/50 animate-float" style={{ animationDelay: '1s' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Star className="w-5 h-5 text-primary" />
            </div>
            <div>
              <div className="text-sm font-medium">Nuevo método</div>
              <div className="text-xs text-muted-foreground">Trading Forex</div>
            </div>
          </div>
        </div>
        
        <div className="absolute top-1/3 left-[15%] bg-card/80 backdrop-blur-sm rounded-2xl p-4 border border-border/50 animate-float" style={{ animationDelay: '2s' }}>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-primary/30 border-2 border-background" />
              <div className="w-8 h-8 rounded-full bg-accent/30 border-2 border-background" />
              <div className="w-8 h-8 rounded-full bg-green-500/30 border-2 border-background" />
            </div>
            <div className="text-sm text-muted-foreground">+1,234 hoy</div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8 animate-slide-up">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">
              {count.toLocaleString()}+ personas ya ganan dinero online
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Descubre{' '}
            <span className="text-gradient">28 métodos</span>
            <br />
            <span className="text-foreground">para ganar dinero</span>
            <br />
            <span className="text-muted-foreground text-3xl sm:text-4xl md:text-5xl">desde cualquier lugar</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Desde freelancing hasta trading, encuentra el camino perfecto para ti. 
            Calculadora de ingresos, test de perfil y guías paso a paso incluidas.
          </p>

          {/* Features */}
          <div className="flex flex-wrap justify-center gap-4 mb-10 animate-slide-up" style={{ animationDelay: '0.25s' }}>
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                {feature}
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8 py-6 text-lg glow-green group"
              onClick={() => {
                document.getElementById('methods')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Explorar Métodos
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-border hover:bg-secondary font-semibold px-8 py-6 text-lg group"
              onClick={() => {
                toast.success('¡Próximamente video de introducción!');
              }}
            >
              <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
              Ver Demo
            </Button>
          </div>

          {/* Stats Preview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <div className="text-center p-4 rounded-2xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <Wallet className="w-5 h-5 text-primary" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">$150M+</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Generados</div>
            </div>
            <div className="text-center p-4 rounded-2xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <Target className="w-5 h-5 text-accent" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">28</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Métodos</div>
            </div>
            <div className="text-center p-4 rounded-2xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">2.5M+</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Usuarios</div>
            </div>
            <div className="text-center p-4 rounded-2xl bg-card/50 border border-border/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <Star className="w-5 h-5 text-accent" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">4.8</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Rating</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}
