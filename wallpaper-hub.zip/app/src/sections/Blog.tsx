import { useState } from 'react';
import { 
  BookOpen, Clock, User, ArrowRight, Calendar,
  TrendingUp, DollarSign, Target, Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Article {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
  featured?: boolean;
}

const articles: Article[] = [
  {
    id: 1,
    title: 'Cómo Ganar tus Primeros $1,000 Online: Guía Completa 2024',
    excerpt: 'Descubre los pasos exactos que usaron 50+ personas para generar su primer ingreso online. Desde la idea hasta el primer pago.',
    category: 'Guía',
    author: 'Carlos Mendoza',
    date: '2024-01-15',
    readTime: '12 min',
    image: 'money',
    featured: true
  },
  {
    id: 2,
    title: 'Freelancing vs Empleo Tradicional: ¿Vale la Pena el Cambio?',
    excerpt: 'Análisis detallado de pros, contras, ingresos reales y cómo hacer la transición sin arriesgar tu estabilidad financiera.',
    category: 'Análisis',
    author: 'María González',
    date: '2024-01-12',
    readTime: '8 min',
    image: 'work'
  },
  {
    id: 3,
    title: 'Los 7 Errores que te Impiden Ganar Dinero con YouTube',
    excerpt: 'Evita estos errores comunes que hacen que el 90% de los canales fallen. Aprende de quienes ya tienen éxito.',
    category: 'YouTube',
    author: 'Diego Hernández',
    date: '2024-01-10',
    readTime: '10 min',
    image: 'video'
  },
  {
    id: 4,
    title: 'Trading para Principiantes: Todo lo que Necesitas Saber',
    excerpt: 'Guía completa para empezar en el trading sin perder tu dinero. Estrategias, riesgos y gestión de capital.',
    category: 'Trading',
    author: 'Ana López',
    date: '2024-01-08',
    readTime: '15 min',
    image: 'chart'
  },
  {
    id: 5,
    title: 'Cómo Crear un Blog que Genere $5,000 al Mes',
    excerpt: 'Estrategia paso a paso para construir un blog rentable. Nichos, SEO, monetización y escalado.',
    category: 'Blogging',
    author: 'Pedro Sánchez',
    date: '2024-01-05',
    readTime: '18 min',
    image: 'blog'
  },
  {
    id: 6,
    title: 'Dropshipping en 2024: ¿Todavía Funciona?',
    excerpt: 'Análisis honesto del estado actual del dropshipping. Lo que funciona, lo que no, y cómo tener éxito hoy.',
    category: 'E-commerce',
    author: 'Laura Martínez',
    date: '2024-01-03',
    readTime: '11 min',
    image: 'shop'
  }
];

const categories = ['Todos', 'Guía', 'Análisis', 'YouTube', 'Trading', 'Blogging', 'E-commerce'];

export function Blog() {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const filteredArticles = activeCategory === 'Todos' 
    ? articles 
    : articles.filter(a => a.category === activeCategory);

  const featuredArticle = articles.find(a => a.featured);

  return (
    <section id="blog" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Blog</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Aprende de los{' '}
            <span className="text-gradient">expertos</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Artículos, guías y estrategias probadas para acelerar tu éxito financiero.
          </p>
        </div>

        {/* Featured Article */}
        {featuredArticle && activeCategory === 'Todos' && (
          <div 
            onClick={() => setSelectedArticle(featuredArticle)}
            className="group cursor-pointer bg-card rounded-3xl border border-primary/30 overflow-hidden mb-12 hover-lift"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="bg-gradient-to-br from-primary/20 to-primary/5 p-12 flex items-center justify-center">
                <div className="text-center">
                  <DollarSign className="w-24 h-24 text-primary mx-auto mb-4" />
                  <Badge className="bg-accent text-accent-foreground">Artículo Destacado</Badge>
                </div>
              </div>
              <div className="p-8 lg:p-12">
                <Badge variant="outline" className="mb-4 border-primary/30 text-primary">
                  {featuredArticle.category}
                </Badge>
                <h3 className="text-2xl lg:text-3xl font-bold mb-4 group-hover:text-primary transition-colors">
                  {featuredArticle.title}
                </h3>
                <p className="text-muted-foreground mb-6">
                  {featuredArticle.excerpt}
                </p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                  <span className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    {featuredArticle.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {featuredArticle.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {featuredArticle.readTime}
                  </span>
                </div>
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90 group/btn">
                  Leer Artículo
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.filter(a => !a.featured || activeCategory !== 'Todos').map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="group cursor-pointer bg-card rounded-2xl border border-border/50 overflow-hidden hover-lift hover:border-primary/50 transition-all"
            >
              <div className="h-48 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                {article.image === 'money' && <DollarSign className="w-16 h-16 text-primary" />}
                {article.image === 'work' && <Target className="w-16 h-16 text-primary" />}
                {article.image === 'video' && <TrendingUp className="w-16 h-16 text-primary" />}
                {article.image === 'chart' && <TrendingUp className="w-16 h-16 text-primary" />}
                {article.image === 'blog' && <BookOpen className="w-16 h-16 text-primary" />}
                {article.image === 'shop' && <DollarSign className="w-16 h-16 text-primary" />}
              </div>
              <div className="p-6">
                <Badge variant="outline" className="mb-3 border-primary/30 text-primary">
                  {article.category}
                </Badge>
                <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {article.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    {article.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {article.readTime}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All */}
        <div className="text-center mt-12">
          <Button
            variant="outline"
            className="border-primary/30 text-primary hover:bg-primary/10"
            onClick={() => {
              toast.success('¡Próximamente más artículos!');
            }}
          >
            Ver Todos los Artículos
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>

      {/* Article Modal */}
      {selectedArticle && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
          onClick={() => setSelectedArticle(null)}
        >
          <div 
            className="bg-card rounded-3xl border border-border max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
              {selectedArticle.image === 'money' && <DollarSign className="w-24 h-24 text-primary" />}
              {selectedArticle.image === 'work' && <Target className="w-24 h-24 text-primary" />}
              {selectedArticle.image === 'video' && <TrendingUp className="w-24 h-24 text-primary" />}
              {selectedArticle.image === 'chart' && <TrendingUp className="w-24 h-24 text-primary" />}
              {selectedArticle.image === 'blog' && <BookOpen className="w-24 h-24 text-primary" />}
              {selectedArticle.image === 'shop' && <DollarSign className="w-24 h-24 text-primary" />}
            </div>
            <div className="p-8">
              <Badge variant="outline" className="mb-4 border-primary/30 text-primary">
                {selectedArticle.category}
              </Badge>
              <h2 className="text-2xl font-bold mb-4">{selectedArticle.title}</h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                <span className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  {selectedArticle.author}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {selectedArticle.date}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {selectedArticle.readTime}
                </span>
              </div>
              <p className="text-muted-foreground mb-6">{selectedArticle.excerpt}</p>
              <div className="bg-secondary/50 rounded-xl p-6 mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <Lightbulb className="w-5 h-5 text-accent" />
                  <span className="font-semibold">Contenido Premium</span>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Este artículo completo está disponible para miembros premium. 
                  Suscríbete para acceder a todo el contenido exclusivo.
                </p>
                <Button 
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={() => {
                    setSelectedArticle(null);
                    document.getElementById('premium')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Ver Planes Premium
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
              <Button 
                variant="outline"
                className="w-full border-border"
                onClick={() => setSelectedArticle(null)}
              >
                Cerrar
              </Button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
