import { useState } from 'react';
import { Search, CheckCircle2, ArrowRight, RotateCcw, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

interface Question {
  id: number;
  question: string;
  options: { label: string; value: string; scores: Record<string, number> }[];
}

const questions: Question[] = [
  {
    id: 1,
    question: '¿Cuánto tiempo puedes dedicar diariamente?',
    options: [
      { label: 'Menos de 2 horas', value: 'low', scores: { passive: 3, content: 1, service: 1, trading: 2 } },
      { label: '2-4 horas', value: 'medium', scores: { passive: 2, content: 2, service: 2, trading: 3 } },
      { label: '4-8 horas', value: 'high', scores: { passive: 1, content: 3, service: 3, trading: 3 } },
      { label: 'Más de 8 horas', value: 'very-high', scores: { passive: 1, content: 3, service: 3, trading: 3 } },
    ],
  },
  {
    id: 2,
    question: '¿Cuál es tu nivel de experiencia técnica?',
    options: [
      { label: 'Principiante - Poco técnico', value: 'beginner', scores: { passive: 3, content: 2, service: 2, trading: 1 } },
      { label: 'Básico - Uso redes sociales', value: 'basic', scores: { passive: 2, content: 3, service: 2, trading: 2 } },
      { label: 'Intermedio - Manejo herramientas digitales', value: 'intermediate', scores: { passive: 2, content: 2, service: 3, trading: 3 } },
      { label: 'Avanzado - Programo o diseño', value: 'advanced', scores: { passive: 1, content: 2, service: 3, trading: 3 } },
    ],
  },
  {
    id: 3,
    question: '¿Prefieres trabajar solo o con personas?',
    options: [
      { label: 'Solo - Me gusta la independencia', value: 'alone', scores: { passive: 3, content: 3, service: 1, trading: 3 } },
      { label: 'Mixto - Depende del proyecto', value: 'mixed', scores: { passive: 2, content: 2, service: 2, trading: 2 } },
      { label: 'Con personas - Me gusta interactuar', value: 'people', scores: { passive: 1, content: 2, service: 3, trading: 1 } },
    ],
  },
  {
    id: 4,
    question: '¿Cuánto dinero puedes invertir inicialmente?',
    options: [
      { label: 'Casi nada ($0-$100)', value: 'none', scores: { passive: 3, content: 3, service: 3, trading: 1 } },
      { label: 'Poco ($100-$500)', value: 'little', scores: { passive: 2, content: 2, service: 2, trading: 2 } },
      { label: 'Moderado ($500-$2,000)', value: 'moderate', scores: { passive: 2, content: 2, service: 2, trading: 3 } },
      { label: 'Significativo ($2,000+)', value: 'significant', scores: { passive: 1, content: 1, service: 1, trading: 3 } },
    ],
  },
  {
    id: 5,
    question: '¿Qué tan rápido necesitas ver resultados?',
    options: [
      { label: 'Inmediato - Esta semana', value: 'immediate', scores: { passive: 1, content: 1, service: 3, trading: 2 } },
      { label: 'Pronto - En 1-2 meses', value: 'soon', scores: { passive: 2, content: 2, service: 2, trading: 3 } },
      { label: 'Paciente - 3-6 meses', value: 'patient', scores: { passive: 3, content: 3, service: 1, trading: 2 } },
      { label: 'Muy paciente - Más de 6 meses', value: 'very-patient', scores: { passive: 3, content: 3, service: 1, trading: 1 } },
    ],
  },
  {
    id: 6,
    question: '¿Qué habilidades destacan en ti?',
    options: [
      { label: 'Creatividad - Escribir, diseñar, crear', value: 'creative', scores: { passive: 2, content: 3, service: 2, trading: 1 } },
      { label: 'Técnica - Programar, analizar datos', value: 'technical', scores: { passive: 2, content: 1, service: 3, trading: 3 } },
      { label: 'Comunicación - Hablar, vender, enseñar', value: 'communication', scores: { passive: 1, content: 3, service: 3, trading: 1 } },
      { label: 'Análisis - Investigación, estrategia', value: 'analytical', scores: { passive: 3, content: 1, service: 2, trading: 3 } },
    ],
  },
];

const recommendations: Record<string, { title: string; methods: string[]; description: string }> = {
  passive: {
    title: 'Ingresos Pasivos',
    methods: ['Affiliate Marketing', 'Blogging', 'YouTube', 'Ebooks & Cursos', 'Fotografía Stock'],
    description: 'Métodos que requieren trabajo inicial pero generan ingresos continuos.',
  },
  content: {
    title: 'Creador de Contenido',
    methods: ['YouTube', 'TikTok', 'Podcasting', 'Blogging', 'Influencer Marketing'],
    description: 'Perfecto para personas creativas que disfrutan crear y compartir.',
  },
  service: {
    title: 'Servicios Freelance',
    methods: ['Freelancing', 'Copywriting', 'Desarrollo Web', 'Diseño Gráfico', 'Consultoría'],
    description: 'Ofrece tus habilidades directamente a clientes por buen dinero.',
  },
  trading: {
    title: 'Trading & Inversión',
    methods: ['Trading Cripto', 'Trading Forex', 'Dropshipping', 'Flipping'],
    description: 'Para quienes buscan resultados rápidos y entienden los riesgos.',
  },
};

export function MethodFinder() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [scores, setScores] = useState<Record<string, number>>({});

  const handleAnswer = (value: string, scoresMap: Record<string, number>) => {
    setAnswers({ ...answers, [questions[currentQuestion].id]: value });
    
    // Accumulate scores
    const newScores = { ...scores };
    Object.entries(scoresMap).forEach(([key, score]) => {
      newScores[key] = (newScores[key] || 0) + score;
    });
    setScores(newScores);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setScores({});
    setShowResults(false);
  };

  const getTopRecommendation = () => {
    const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    return sorted[0]?.[0] || 'passive';
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (showResults) {
    const topRec = getTopRecommendation();
    const rec = recommendations[topRec];

    return (
      <section className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-dark" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-card rounded-3xl border border-primary/30 p-8 lg:p-12 text-center">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-10 h-10 text-primary" />
            </div>
            
            <h2 className="text-3xl font-bold mb-4">¡Tu perfil está listo!</h2>
            <p className="text-muted-foreground mb-8">
              Basado en tus respuestas, estos métodos son perfectos para ti:
            </p>

            <div className="bg-primary/10 rounded-2xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-primary mb-2">{rec.title}</h3>
              <p className="text-muted-foreground mb-6">{rec.description}</p>
              
              <div className="flex flex-wrap justify-center gap-3">
                {rec.methods.map((method) => (
                  <span
                    key={method}
                    className="px-4 py-2 rounded-full bg-card border border-primary/30 text-sm font-medium"
                  >
                    {method}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => {
                  toast.success('¡Te has suscrito al plan personalizado!');
                }}
              >
                Recibir Plan Detallado
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button 
                variant="outline"
                onClick={resetQuiz}
                className="border-border"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Hacer Test de Nuevo
              </Button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Search className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">Test de Perfil</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Encuentra tu método{' '}
            <span className="text-gradient">ideal</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Responde 6 preguntas rápidas y descubre qué métodos se adaptan mejor a tu perfil.
          </p>
        </div>

        {/* Quiz Card */}
        <div className="bg-card rounded-3xl border border-border/50 p-8">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Pregunta {currentQuestion + 1} de {questions.length}</span>
              <span className="text-primary">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-6">
              {questions[currentQuestion].question}
            </h3>

            <div className="space-y-3">
              {questions[currentQuestion].options.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleAnswer(option.value, option.scores)}
                  className="w-full p-4 rounded-xl border border-border/50 bg-secondary/30 hover:bg-primary/10 hover:border-primary/30 transition-all text-left flex items-center gap-3 group"
                >
                  <div className="w-6 h-6 rounded-full border-2 border-muted-foreground group-hover:border-primary flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <span className="text-foreground">{option.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
