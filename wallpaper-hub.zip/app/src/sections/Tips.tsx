import { useState } from 'react';
import { 
  Lightbulb, Shield, Clock, Target, TrendingUp,
  ChevronDown, CheckCircle2, AlertCircle, Rocket,
  BookOpen, Zap, Star,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Tip {
  id: number;
  title: string;
  description: string;
  icon: React.ElementType;
  points: string[];
}

const tips: Tip[] = [
  {
    id: 1,
    title: 'Comienza con lo Básico',
    description: 'No necesitas invertir dinero para empezar a ganar. Hay métodos completamente gratuitos.',
    icon: Rocket,
    points: [
      'Identifica tus habilidades actuales',
      'Elige un método que se adapte a tu tiempo',
      'Comienza como proyecto paralelo',
      'No dejes tu trabajo actual de inmediato',
      'Establece metas realistas de corto plazo'
    ]
  },
  {
    id: 2,
    title: 'Evita Estafas',
    description: 'Aprende a identificar oportunidades reales vs. promesas falsas de dinero rápido.',
    icon: Shield,
    points: [
      'Desconfía de "dinero fácil" o "rico overnight"',
      'Nunca pagues por "secretos" de ganar dinero',
      'Investiga antes de invertir en cualquier plataforma',
      'Lee reseñas de otros usuarios',
      'Si suena demasiado bueno, probablemente lo es'
    ]
  },
  {
    id: 3,
    title: 'Gestiona tu Tiempo',
    description: 'La clave del éxito es la consistencia, no trabajar 12 horas al día.',
    icon: Clock,
    points: [
      'Dedica 1-2 horas diarias consistentemente',
      'Crea un horario y respétalo',
      'Elimina distracciones durante el trabajo',
      'Toma descansos regulares',
      'Usa técnicas como Pomodoro'
    ]
  },
  {
    id: 4,
    title: 'Establece Metas Claras',
    description: 'Define objetivos específicos y medibles para mantenerte motivado.',
    icon: Target,
    points: [
      'Define tu meta de ingresos mensual',
      'Divide objetivos grandes en pequeños pasos',
      'Celebra cada logro, por pequeño que sea',
      'Revisa y ajusta tus metas regularmente',
      'Mantén un diario de progreso'
    ]
  },
  {
    id: 5,
    title: 'Invierte en Aprender',
    description: 'El conocimiento es tu mejor inversión. Nunca dejes de aprender.',
    icon: BookOpen,
    points: [
      'Toma cursos relevantes a tu método',
      'Lee libros de emprendedores exitosos',
      'Únete a comunidades de tu nicho',
      'Aprende de tus errores',
      'Mantente actualizado con tendencias'
    ]
  },
  {
    id: 6,
    title: 'Construye tu Marca',
    description: 'Tu reputación personal es tu activo más valioso.',
    icon: Star,
    points: [
      'Crea presencia profesional online',
      'Entrega siempre calidad',
      'Sé consistente en tu mensaje',
      'Pide y muestra testimonios',
      'Networking con otros profesionales'
    ]
  }
];

const commonMistakes = [
  'Esperar resultados inmediatos sin esfuerzo',
  'Saltar de un método a otro sin dar tiempo',
  'No invertir en aprender nuevas habilidades',
  'Ignorar el marketing y la promoción personal',
  'Subvalorar tu trabajo desde el inicio',
  'No llevar registro de ingresos y gastos',
  'Tratarlo como hobby en lugar de negocio'
];

const successStories = [
  {
    name: 'Pedro S.',
    method: 'Freelancing',
    before: '$0/mes',
    after: '$5,200/mes',
    time: '8 meses',
    tip: 'La consistencia diaria es clave. Nunca salté un día de trabajo.'
  },
  {
    name: 'Laura M.',
    method: 'YouTube',
    before: '$0/mes',
    after: '$8,500/mes',
    time: '12 meses',
    tip: 'Publiqué 3 videos por semana durante un año sin fallar.'
  },
  {
    name: 'Juan K.',
    method: 'Dropshipping',
    before: '-$500 (inversión)',
    after: '$15,000/mes',
    time: '6 meses',
    tip: 'Estudié marketing antes de invertir un solo dólar en ads.'
  }
];

export function Tips() {
  const [expandedTip, setExpandedTip] = useState<number | null>(1);

  return (
    <section id="tips" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Lightbulb className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Consejos Expertos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Tips para{' '}
            <span className="text-gradient">maximizar tus ganancias</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Aprende de los errores comunes y aplica estrategias probadas para acelerar tu éxito.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tips Accordion */}
          <div className="lg:col-span-2 space-y-4">
            {tips.map((tip) => (
              <div
                key={tip.id}
                className={`bg-card rounded-2xl border transition-all duration-300 ${
                  expandedTip === tip.id 
                    ? 'border-primary/50 glow-green' 
                    : 'border-border/50 hover:border-border'
                }`}
              >
                <button
                  onClick={() => setExpandedTip(expandedTip === tip.id ? null : tip.id)}
                  className="w-full p-6 flex items-center justify-between text-left"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                      expandedTip === tip.id ? 'bg-primary/20' : 'bg-secondary'
                    }`}>
                      <tip.icon className={`w-6 h-6 ${
                        expandedTip === tip.id ? 'text-primary' : 'text-muted-foreground'
                      }`} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{tip.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                        {tip.description}
                      </p>
                    </div>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${
                    expandedTip === tip.id ? 'rotate-180' : ''
                  }`} />
                </button>
                
                {expandedTip === tip.id && (
                  <div className="px-6 pb-6 pt-2 border-t border-border/50">
                    <p className="text-muted-foreground mb-4">{tip.description}</p>
                    <ul className="space-y-3">
                      {tip.points.map((point, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-foreground">{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Common Mistakes Card */}
            <div className="bg-card rounded-2xl border border-border/50 p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                  <AlertCircle className="w-5 h-5 text-red-400" />
                </div>
                <h3 className="font-semibold text-foreground">Errores Comunes</h3>
              </div>
              
              <p className="text-sm text-muted-foreground mb-4">
                Evita estos errores que la mayoría de principiantes cometen:
              </p>

              <ul className="space-y-3">
                {commonMistakes.map((mistake, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-red-500/10 flex items-center justify-center flex-shrink-0 text-xs text-red-400 font-medium">
                      {index + 1}
                    </span>
                    <span className="text-sm text-foreground">{mistake}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Quick Tip */}
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl border border-primary/20 p-6">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-5 h-5 text-accent" />
                <span className="font-semibold">Consejo Rápido</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                El éxito requiere paciencia y consistencia. No hay atajos, pero sí caminos probados.
              </p>
              <Button 
                variant="outline" 
                className="w-full border-primary/30 text-primary hover:bg-primary/10"
                onClick={() => {
                  document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Calcular mis Potenciales
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>

        {/* Success Stories */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">
            De <span className="text-gradient">0 a éxito</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {successStories.map((story, index) => (
              <div key={index} className="bg-card rounded-2xl border border-border/50 p-6 hover-lift">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
                    {story.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <div className="font-semibold">{story.name}</div>
                    <div className="text-sm text-muted-foreground">{story.method}</div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-4 p-3 bg-secondary/50 rounded-xl">
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Antes</div>
                    <div className="text-red-400 font-semibold">{story.before}</div>
                  </div>
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Después</div>
                    <div className="text-green-400 font-semibold">{story.after}</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{story.time}</span>
                </div>
                
                <p className="text-sm text-muted-foreground italic">"{story.tip}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
