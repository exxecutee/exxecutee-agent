import { useState } from 'react';
import { 
  HelpCircle, ChevronDown, MessageCircle, Mail
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqs: FAQItem[] = [
  {
    category: 'General',
    question: '¿Realmente se puede ganar dinero online?',
    answer: 'Sí, absolutamente. Millones de personas en todo el mundo generan ingresos online de manera legítima. Sin embargo, requiere trabajo, dedicación y paciencia. No existe el "dinero fácil" - los métodos que presentamos requieren esfuerzo consistente, pero los resultados son reales y alcanzables.'
  },
  {
    category: 'General',
    question: '¿Cuánto dinero necesito para empezar?',
    answer: 'Depende del método. Algunos como freelancing, YouTube o affiliate marketing puedes empezar con $0. Otros como dropshipping o trading requieren una inversión inicial de $100-$1000. En cada método detallamos exactamente cuánto necesitas para comenzar.'
  },
  {
    category: 'General',
    question: '¿Cuánto tiempo tomará ver resultados?',
    answer: 'Varía según el método y tu dedicación. Algunos métodos como freelancing o trading pueden generar ingresos en semanas. Otros como YouTube o blogging pueden tomar 6-12 meses para generar ingresos significativos. La clave es la consistencia y no rendirse.'
  },
  {
    category: 'General',
    question: '¿Necesito experiencia previa?',
    answer: 'No necesariamente. Muchos métodos están diseñados para principiantes y puedes aprender sobre la marcha. Sin embargo, tener habilidades previas (escritura, diseño, programación) puede acelerar tu progreso. Ofrecemos recursos de aprendizaje para todos los niveles.'
  },
  {
    category: 'Métodos',
    question: '¿Cuál es el mejor método para empezar?',
    answer: 'Depende de tu situación. Si necesitas dinero rápido: freelancing o trading. Si buscas ingresos pasivos a largo plazo: YouTube, blogging o affiliate marketing. Si tienes capital para invertir: dropshipping o e-commerce. Usa nuestro test de perfil para encontrar tu método ideal.'
  },
  {
    category: 'Métodos',
    question: '¿Puedo combinar varios métodos?',
    answer: '¡Absolutamente! De hecho, los emprendedores más exitosos diversifican sus fuentes de ingreso. Puedes empezar con uno y agregar más conforme ganes experiencia. Solo asegúrate de dominar un método antes de agregar otro.'
  },
  {
    category: 'Métodos',
    question: '¿Los métodos funcionan en cualquier país?',
    answer: 'La mayoría de los métodos funcionan globalmente, aunque algunos pueden tener restricciones dependiendo de tu ubicación. Plataformas como Upwork, Fiverr, YouTube y affiliate marketing están disponibles en la mayoría de países. Siempre verificamos la disponibilidad por región.'
  },
  {
    category: 'Premium',
    question: '¿Qué incluye la suscripción Premium?',
    answer: 'Acceso completo a los 28 métodos detallados con guías paso a paso, cursos en video, herramientas exclusivas, comunidad privada, soporte prioritario y mentorías (plan Elite). También recibes actualizaciones mensuales con nuevos métodos y estrategias.'
  },
  {
    category: 'Premium',
    question: '¿Puedo cancelar mi suscripción en cualquier momento?',
    answer: 'Sí, puedes cancelar tu suscripción cuando quieras. No hay contratos de permanencia. Si cancelas, seguirás teniendo acceso hasta el final del período pagado. También ofrecemos garantía de 30 días para nuevas suscripciones.'
  },
  {
    category: 'Premium',
    question: '¿Vale la pena pagar por Premium?',
    answer: 'Nuestros miembros Premium reportan resultados 3x más rápidos que los usuarios gratuitos. Las guías detalladas, mentorías y comunidad te ahorran meses de prueba y error. Muchos miembros recuperan su inversión en el primer mes.'
  },
  {
    category: 'Seguridad',
    question: '¿Es seguro compartir mi información de pago?',
    answer: 'Absolutamente. Usamos Stripe y PayPal, dos de las pasarelas de pago más seguras del mundo. Nunca almacenamos los detalles de tu tarjeta en nuestros servidores. Toda la información está encriptada.'
  },
  {
    category: 'Seguridad',
    question: '¿Cómo evito estafas online?',
    answer: 'Nunca pagues por "secretos" de hacer dinero. Desconfía de promesas de "dinero fácil" o "rico overnight". Investiga cualquier plataforma antes de invertir. Usa nuestro sistema de reviews para verificar plataformas. Y recuerda: si suena demasiado bueno para ser verdad, probablemente lo es.'
  },
  {
    category: 'Soporte',
    question: '¿Cómo puedo obtener ayuda?',
    answer: 'Los usuarios gratuitos tienen acceso a nuestra base de conocimientos y comunidad. Los miembros Pro reciben soporte prioritario por email con respuesta en 24h. Los miembros Elite tienen acceso a chat directo y consultorías mensuales.'
  },
  {
    category: 'Soporte',
    question: '¿Ofrecen reembolsos?',
    answer: 'Sí, ofrecemos garantía de 30 días para todas las suscripciones nuevas. Si no estás satisfecho, contáctanos y te reembolsamos el 100% sin preguntas.'
  }
];

const categories = ['Todos', 'General', 'Métodos', 'Premium', 'Seguridad', 'Soporte'];

export function FAQ() {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [expandedItems, setExpandedItems] = useState<number[]>([0]);

  const filteredFaqs = activeCategory === 'Todos' 
    ? faqs 
    : faqs.filter(f => f.category === activeCategory);

  const toggleItem = (index: number) => {
    if (expandedItems.includes(index)) {
      setExpandedItems(expandedItems.filter(i => i !== index));
    } else {
      setExpandedItems([...expandedItems, index]);
    }
  };

  return (
    <section id="faq" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <HelpCircle className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">FAQ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Preguntas{' '}
            <span className="text-gradient">frecuentes</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Encuentra respuestas a las dudas más comunes sobre ganar dinero online.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="space-y-4 mb-12">
          {filteredFaqs.map((faq, index) => (
            <div
              key={index}
              className={`bg-card rounded-2xl border transition-all duration-300 ${
                expandedItems.includes(index) 
                  ? 'border-primary/50' 
                  : 'border-border/50'
              }`}
            >
              <button
                onClick={() => toggleItem(index)}
                className="w-full p-6 flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="text-xs">
                    {faq.category}
                  </Badge>
                  <span className="font-medium">{faq.question}</span>
                </div>
                <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${
                  expandedItems.includes(index) ? 'rotate-180' : ''
                }`} />
              </button>
              
              {expandedItems.includes(index) && (
                <div className="px-6 pb-6 pt-2 border-t border-border/50">
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="bg-card rounded-3xl border border-border/50 p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <MessageCircle className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-bold mb-2">¿No encontraste tu respuesta?</h3>
          <p className="text-muted-foreground mb-6">
            Estamos aquí para ayudarte. Contáctanos y te responderemos en menos de 24 horas.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => {
                toast.success('¡Próximamente chat en vivo!');
              }}
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat en Vivo
            </Button>
            <Button 
              variant="outline"
              className="border-border"
              onClick={() => {
                window.location.href = 'mailto:hola@ganadinero.com';
              }}
            >
              <Mail className="w-4 h-4 mr-2" />
              Enviar Email
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
