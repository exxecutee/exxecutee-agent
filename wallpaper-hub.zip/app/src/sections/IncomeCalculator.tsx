import { useState } from 'react';
import { Calculator, DollarSign, Clock, TrendingUp, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

interface CalculationResult {
  daily: number;
  weekly: number;
  monthly: number;
  yearly: number;
  totalHours: number;
}

export function IncomeCalculator() {
  const [hoursPerDay, setHoursPerDay] = useState(4);
  const [daysPerWeek, setDaysPerWeek] = useState(5);
  const [experience, setExperience] = useState(2);
  const [method, setMethod] = useState('freelancing');

  const methods = [
    { id: 'freelancing', name: 'Freelancing', baseRate: 20, multiplier: 1 },
    { id: 'trading', name: 'Trading', baseRate: 50, multiplier: 1.5 },
    { id: 'youtube', name: 'YouTube', baseRate: 15, multiplier: 0.8 },
    { id: 'copywriting', name: 'Copywriting', baseRate: 30, multiplier: 1.2 },
    { id: 'development', name: 'Desarrollo Web', baseRate: 50, multiplier: 1.5 },
    { id: 'dropshipping', name: 'Dropshipping', baseRate: 25, multiplier: 1 },
    { id: 'consulting', name: 'Consultoría', baseRate: 60, multiplier: 1.8 },
    { id: 'affiliate', name: 'Affiliate Marketing', baseRate: 20, multiplier: 0.9 },
  ];

  const experienceMultipliers = [0.7, 0.85, 1, 1.3, 1.6, 2];

  const calculateIncome = (): CalculationResult => {
    const selectedMethod = methods.find(m => m.id === method);
    const baseRate = selectedMethod ? selectedMethod.baseRate : 25;
    const expMultiplier = experienceMultipliers[experience - 1] || 1;
    const finalHourlyRate = Math.round(baseRate * expMultiplier);
    
    const daily = finalHourlyRate * hoursPerDay;
    const weekly = daily * daysPerWeek;
    const monthly = weekly * 4.33;
    const yearly = monthly * 12;
    const totalHours = hoursPerDay * daysPerWeek * 4.33;

    return { daily, weekly, monthly, yearly, totalHours };
  };

  const results = calculateIncome();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <section id="calculator" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent/10 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Calculator className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Calculadora de Ingresos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Calcula cuánto podrías{' '}
            <span className="text-gradient">ganar</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Ajusta los parámetros según tu situación y descubre tu potencial de ingresos mensuales.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Inputs */}
          <div className="bg-card rounded-3xl border border-border/50 p-8">
            <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Info className="w-5 h-5 text-primary" />
              Configura tu situación
            </h3>

            <div className="space-y-8">
              {/* Method Selection */}
              <div>
                <label className="block text-sm font-medium mb-3">Método de ingreso</label>
                <div className="grid grid-cols-2 gap-2">
                  {methods.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setMethod(m.id)}
                      className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                        method === m.id
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      {m.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Experience Level */}
              <div>
                <label className="block text-sm font-medium mb-3">
                  Nivel de experiencia: {' '}
                  <span className="text-primary">
                    {experience === 1 && 'Principiante'}
                    {experience === 2 && 'Básico'}
                    {experience === 3 && 'Intermedio'}
                    {experience === 4 && 'Avanzado'}
                    {experience === 5 && 'Experto'}
                    {experience === 6 && 'Maestro'}
                  </span>
                </label>
                <Slider
                  value={[experience]}
                  onValueChange={(value) => setExperience(value[0])}
                  min={1}
                  max={6}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>Principiante</span>
                  <span>Maestro</span>
                </div>
              </div>

              {/* Hours per Day */}
              <div>
                <label className="block text-sm font-medium mb-3">
                  Horas por día: <span className="text-primary">{hoursPerDay}h</span>
                </label>
                <Slider
                  value={[hoursPerDay]}
                  onValueChange={(value) => setHoursPerDay(value[0])}
                  min={1}
                  max={12}
                  step={0.5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>1h</span>
                  <span>12h</span>
                </div>
              </div>

              {/* Days per Week */}
              <div>
                <label className="block text-sm font-medium mb-3">
                  Días por semana: <span className="text-primary">{daysPerWeek} días</span>
                </label>
                <Slider
                  value={[daysPerWeek]}
                  onValueChange={(value) => setDaysPerWeek(value[0])}
                  min={1}
                  max={7}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>1 día</span>
                  <span>7 días</span>
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="space-y-6">
            {/* Main Result */}
            <div className="bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl border border-primary/30 p-8">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
                <span className="text-muted-foreground">Ingresos mensuales estimados</span>
              </div>
              <div className="text-5xl sm:text-6xl font-bold text-gradient mb-2">
                {formatCurrency(results.monthly)}
              </div>
              <p className="text-sm text-muted-foreground">
                Basado en {results.totalHours.toFixed(1)} horas de trabajo al mes
              </p>
            </div>

            {/* Breakdown */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-card rounded-2xl border border-border/50 p-6">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Diario</span>
                </div>
                <div className="text-2xl font-bold">{formatCurrency(results.daily)}</div>
              </div>
              <div className="bg-card rounded-2xl border border-border/50 p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Semanal</span>
                </div>
                <div className="text-2xl font-bold">{formatCurrency(results.weekly)}</div>
              </div>
            </div>

            {/* Yearly */}
            <div className="bg-card rounded-2xl border border-border/50 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-sm text-muted-foreground">Proyección anual</span>
                  <div className="text-3xl font-bold text-gradient-gold">{formatCurrency(results.yearly)}</div>
                </div>
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-accent" />
                </div>
              </div>
            </div>

            {/* CTA */}
            <Button 
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 text-lg"
              onClick={() => {
                toast.success('¡Te has registrado para recibir un plan personalizado!');
              }}
            >
              Recibir Plan Personalizado
            </Button>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
            <Info className="w-4 h-4 inline mr-1" />
            Estas cifras son estimaciones basadas en promedios de la industria. 
            Los resultados reales pueden variar según tu dedicación, habilidades y condiciones del mercado.
          </p>
        </div>
      </div>
    </section>
  );
}
