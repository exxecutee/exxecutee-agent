import { useState } from 'react';
import { 
  Star, ThumbsUp, ThumbsDown, MessageSquare, 
  TrendingUp, DollarSign, Users, Shield, ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Review {
  id: number;
  user: string;
  avatar: string;
  rating: number;
  date: string;
  comment: string;
  helpful: number;
  method: string;
}

interface Platform {
  id: number;
  name: string;
  category: string;
  logo: string;
  rating: number;
  reviewCount: number;
  description: string;
  pros: string[];
  cons: string[];
  stats: {
    users: string;
    avgEarnings: string;
    payoutTime: string;
    fee: string;
  };
  reviews: Review[];
}

const platforms: Platform[] = [
  {
    id: 1,
    name: 'Upwork',
    category: 'Freelance',
    logo: 'U',
    rating: 4.5,
    reviewCount: 125000,
    description: 'La plataforma de freelancing más grande del mundo. Conecta profesionales con clientes globales.',
    pros: ['Miles de trabajos disponibles', 'Protección de pago', 'Perfil profesional', 'Reviews verificadas'],
    cons: ['Fee del 10-20%', 'Competencia alta', 'Aprobación de perfil', 'Proposals limitadas gratis'],
    stats: {
      users: '18M+',
      avgEarnings: '$28/hora',
      payoutTime: '5-7 días',
      fee: '10-20%'
    },
    reviews: [
      { id: 1, user: 'María G.', avatar: 'MG', rating: 5, date: '2024-01-15', comment: 'Excelente plataforma. En 3 meses ya tenía clientes recurrentes.', helpful: 234, method: 'Freelancing' },
      { id: 2, user: 'Carlos R.', avatar: 'CR', rating: 4, date: '2024-01-10', comment: 'Buena pero la competencia es feroz. Necesitas destacar.', helpful: 189, method: 'Freelancing' },
      { id: 3, user: 'Ana L.', avatar: 'AL', rating: 3, date: '2024-01-05', comment: 'Los fees son altos pero la protección de pago vale la pena.', helpful: 156, method: 'Freelancing' },
    ]
  },
  {
    id: 2,
    name: 'Fiverr',
    category: 'Freelance',
    logo: 'F',
    rating: 4.4,
    reviewCount: 98000,
    description: 'Marketplace de servicios digitales. Ofrece "gigs" desde $5.',
    pros: ['Fácil empezar', 'Clientes llegan a ti', 'Gigs escalables', 'Niveles de vendedor'],
    cons: ['20% de comisión', 'Precios bajos iniciales', 'Competencia extrema', 'Algoritmo impredecible'],
    stats: {
      users: '4M+',
      avgEarnings: '$500/mes',
      payoutTime: '14 días',
      fee: '20%'
    },
    reviews: [
      { id: 4, user: 'Pedro S.', avatar: 'PS', rating: 5, date: '2024-01-12', comment: 'Empecé con $5 y ahora cobro $200 por proyecto. Constancia es clave.', helpful: 312, method: 'Freelancing' },
      { id: 5, user: 'Laura M.', avatar: 'LM', rating: 4, date: '2024-01-08', comment: 'Buena para empezar pero difícil escalar. Mucha competencia.', helpful: 178, method: 'Freelancing' },
    ]
  },
  {
    id: 3,
    name: 'YouTube',
    category: 'Contenido',
    logo: 'Y',
    rating: 4.7,
    reviewCount: 250000,
    description: 'La plataforma de video más grande. Monetiza con ads, membresías y Super Chats.',
    pros: ['Audiencia masiva', 'Múltiples ingresos', 'Pasivo a largo plazo', 'Construye marca personal'],
    cons: ['Requisitos estrictos', 'Algoritmo cambia', 'Tarda en monetizar', 'Copyright issues'],
    stats: {
      users: '2.7B+',
      avgEarnings: '$3-5/1000 views',
      payoutTime: '21 días',
      fee: '45% de ads'
    },
    reviews: [
      { id: 6, user: 'Diego H.', avatar: 'DH', rating: 5, date: '2024-01-14', comment: '6 meses para monetizar, ahora gano $2000/mes pasivo.', helpful: 567, method: 'YouTube' },
      { id: 7, user: 'Sofia P.', avatar: 'SP', rating: 5, date: '2024-01-11', comment: 'Cambiaron mi vida. Requiere paciencia pero vale cada segundo.', helpful: 423, method: 'YouTube' },
    ]
  },
  {
    id: 4,
    name: 'Shopify',
    category: 'E-commerce',
    logo: 'S',
    rating: 4.6,
    reviewCount: 85000,
    description: 'Plataforma líder para crear tiendas online sin conocimientos técnicos.',
    pros: ['Fácil de usar', 'Temas profesionales', 'Apps ilimitadas', 'Soporte 24/7'],
    cons: ['Costo mensual', 'Transaction fees', 'Apps costosas', 'Marketing es tu responsabilidad'],
    stats: {
      users: '4.4M+',
      avgEarnings: 'Variable',
      payoutTime: 'Inmediato',
      fee: '$29/mes + 2.9%'
    },
    reviews: [
      { id: 8, user: 'Juan K.', avatar: 'JK', rating: 4, date: '2024-01-13', comment: 'Excelente plataforma pero necesitas presupuesto para marketing.', helpful: 289, method: 'Dropshipping' },
      { id: 9, user: 'Elena T.', avatar: 'ET', rating: 5, date: '2024-01-09', comment: 'Mi tienda factura $10k/mes. Shopify hace todo fácil.', helpful: 445, method: 'E-commerce' },
    ]
  },
  {
    id: 5,
    name: 'Binance',
    category: 'Trading',
    logo: 'B',
    rating: 4.3,
    reviewCount: 150000,
    description: 'El exchange de criptomonedas más grande con la mayor liquidez.',
    pros: ['500+ criptomonedas', 'Bajas comisiones', 'Trading avanzado', 'Staking disponible'],
    cons: ['Complejo para novatos', 'Soporte lento', 'Regulación variable', 'Riesgo de hackeo'],
    stats: {
      users: '150M+',
      avgEarnings: 'Variable',
      payoutTime: 'Inmediato',
      fee: '0.1%'
    },
    reviews: [
      { id: 10, user: 'Roberto N.', avatar: 'RN', rating: 4, date: '2024-01-16', comment: 'Excelente para trading pero aprende antes de invertir.', helpful: 334, method: 'Trading' },
      { id: 11, user: 'Carmen V.', avatar: 'CV', rating: 3, date: '2024-01-07', comment: 'Buena plataforma pero perdí dinero al inicio. Muy riesgoso.', helpful: 267, method: 'Trading' },
    ]
  },
  {
    id: 6,
    name: 'Amazon Associates',
    category: 'Afiliados',
    logo: 'A',
    rating: 4.5,
    reviewCount: 75000,
    description: 'El programa de afiliados más grande. Gana comisiones por recomendar productos.',
    pros: ['Marca confiable', 'Millones de productos', 'Conversión alta', 'Pagos confiables'],
    cons: ['Comisiones bajas (1-10%)', 'Cookie 24 horas', 'Cuenta puede cerrarse', 'Competencia masiva'],
    stats: {
      users: '900K+',
      avgEarnings: '$500-2000/mes',
      payoutTime: '60 días',
      fee: '1-10% comisión'
    },
    reviews: [
      { id: 12, user: 'Miguel A.', avatar: 'MA', rating: 5, date: '2024-01-15', comment: 'Gano $1500/mes con un blog de reviews. Muy estable.', helpful: 398, method: 'Affiliate' },
      { id: 13, user: 'Patricia L.', avatar: 'PL', rating: 4, date: '2024-01-11', comment: 'Buen ingreso extra pero las comisiones han bajado.', helpful: 234, method: 'Affiliate' },
    ]
  }
];

export function PlatformReviews() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);
  const [likedReviews, setLikedReviews] = useState<number[]>([]);

  const handleLike = (reviewId: number) => {
    if (!likedReviews.includes(reviewId)) {
      setLikedReviews([...likedReviews, reviewId]);
      toast.success('¡Gracias por tu feedback!');
    }
  };

  return (
    <section id="reviews" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <MessageSquare className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Reviews de la Comunidad</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Opiniones{' '}
            <span className="text-gradient">reales de usuarios</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubre lo que la comunidad dice sobre cada plataforma antes de empezar.
          </p>
        </div>

        {/* Platforms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {platforms.map((platform) => (
            <div
              key={platform.id}
              onClick={() => setSelectedPlatform(platform)}
              className="group cursor-pointer bg-card rounded-2xl border border-border/50 p-6 hover-lift hover:border-primary/50 transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-xl font-bold text-primary">
                    {platform.logo}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
                      {platform.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{platform.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-accent fill-accent" />
                    <span className="font-semibold">{platform.rating}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{platform.reviewCount.toLocaleString()} reviews</p>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {platform.description}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-secondary/50 rounded-lg p-3">
                  <Users className="w-4 h-4 text-primary mb-1" />
                  <div className="text-sm font-medium">{platform.stats.users}</div>
                  <div className="text-xs text-muted-foreground">usuarios</div>
                </div>
                <div className="bg-secondary/50 rounded-lg p-3">
                  <DollarSign className="w-4 h-4 text-primary mb-1" />
                  <div className="text-sm font-medium">{platform.stats.avgEarnings}</div>
                  <div className="text-xs text-muted-foreground">promedio</div>
                </div>
              </div>

              {/* CTA */}
              <Button variant="outline" className="w-full border-border group/btn">
                Ver Reviews
                <ExternalLink className="w-4 h-4 ml-2 group-hover/btn:translate-x-0.5 transition-transform" />
              </Button>
            </div>
          ))}
        </div>

        {/* Platform Detail Modal */}
        {selectedPlatform && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
            onClick={() => setSelectedPlatform(null)}
          >
            <div 
              className="bg-card rounded-3xl border border-border max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-border/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl font-bold text-primary">
                      {selectedPlatform.logo}
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold">{selectedPlatform.name}</h2>
                      <p className="text-muted-foreground">{selectedPlatform.category}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedPlatform(null)}
                    className="p-2 hover:bg-secondary rounded-lg transition-colors"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Modal Content */}
              <div className="p-6 space-y-8">
                {/* Stats Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-secondary/50 rounded-xl p-4 text-center">
                    <Users className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-sm text-muted-foreground">Usuarios</div>
                    <div className="font-semibold">{selectedPlatform.stats.users}</div>
                  </div>
                  <div className="bg-secondary/50 rounded-xl p-4 text-center">
                    <DollarSign className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-sm text-muted-foreground">Promedio</div>
                    <div className="font-semibold">{selectedPlatform.stats.avgEarnings}</div>
                  </div>
                  <div className="bg-secondary/50 rounded-xl p-4 text-center">
                    <TrendingUp className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-sm text-muted-foreground">Pago</div>
                    <div className="font-semibold">{selectedPlatform.stats.payoutTime}</div>
                  </div>
                  <div className="bg-secondary/50 rounded-xl p-4 text-center">
                    <Shield className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-sm text-muted-foreground">Fee</div>
                    <div className="font-semibold">{selectedPlatform.stats.fee}</div>
                  </div>
                </div>

                {/* Pros & Cons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3 text-green-400 flex items-center gap-2">
                      <ThumbsUp className="w-5 h-5" />
                      Pros
                    </h3>
                    <ul className="space-y-2">
                      {selectedPlatform.pros.map((pro, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <svg className="w-5 h-5 text-green-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="text-muted-foreground">{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-3 text-red-400 flex items-center gap-2">
                      <ThumbsDown className="w-5 h-5" />
                      Contras
                    </h3>
                    <ul className="space-y-2">
                      {selectedPlatform.cons.map((con, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <svg className="w-5 h-5 text-red-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                          <span className="text-muted-foreground">{con}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Reviews */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Reviews Destacadas</h3>
                  <div className="space-y-4">
                    {selectedPlatform.reviews.map((review) => (
                      <div key={review.id} className="bg-secondary/30 rounded-xl p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-medium">
                              {review.avatar}
                            </div>
                            <div>
                              <div className="font-medium">{review.user}</div>
                              <div className="text-xs text-muted-foreground">{review.date}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-accent fill-accent" />
                            <span className="text-sm">{review.rating}</span>
                          </div>
                        </div>
                        <p className="text-muted-foreground mb-3">{review.comment}</p>
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => handleLike(review.id)}
                            className={`flex items-center gap-1 text-sm ${
                              likedReviews.includes(review.id) 
                                ? 'text-primary' 
                                : 'text-muted-foreground hover:text-foreground'
                            }`}
                          >
                            <ThumbsUp className="w-4 h-4" />
                            <span>{review.helpful + (likedReviews.includes(review.id) ? 1 : 0)} útil</span>
                          </button>
                          <Badge variant="outline" className="text-xs">
                            {review.method}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <div className="flex gap-4">
                  <Button 
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => {
                      toast.success(`Redirigiendo a ${selectedPlatform.name}...`);
                    }}
                  >
                    Visitar {selectedPlatform.name}
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                  <Button 
                    variant="outline"
                    className="border-border"
                    onClick={() => setSelectedPlatform(null)}
                  >
                    Cerrar
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
